#include "main.h"

CImageBuf myPic;			

CScene    myScene;			

CTransRot setModel;			
int viewportW,viewportH;	

double pModelMat[16];		
double pViewMat[16];		

int main(int argc, char** argv)
{
    printHelp();                       
    init_glut(&argc, argv);		        
	init_ogl();							

    init_raytrace();                    
	glutMainLoop();

	return 0;							
}

void printHelp(void)
{
	cout << "OpenGL Preview on left, Ray Tracing on Right." << endl;
	cout << "---------------------------------------------"<< endl << endl;
	cout << "GL_MODELVIEW:  rotate   --Right Mouse Drag" << endl;
	cout << "               translate--Arrow Keys" << endl;
	cout << "               track    -- +, - Keys" << endl;
	cout << "               reset    -- 'R' key  " << endl;
	cout << "               print    -- 'M' key  " << endl << endl;

	cout << "Ray Tracing:   start    --'t' or 'T' key" << endl;
	cout << "               antiAlias--'a' or 'A' key toggles on/off" << endl;
	cout << "               recursion--'d' for more depth; 'D' for less";
    cout << endl << endl;
    cout << "Help:   -- 'h' or 'H' key" << endl;
	cout << "Quit:   -- 'Q','q' or 'ESC' key" << endl << endl;
}

void init_glut(int *argc, char **argv)
{
	glutInit(argc, argv);			
							
							
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	glutInitWindowSize(JT_WIDTH*2, JT_HEIGHT);	
	glutInitWindowPosition(JT_XPOS, JT_XPOS);	
	glutCreateWindow(JT_TITLE);					

	glutDisplayFunc(display);			
	glutKeyboardFunc(keyboard);		
	glutSpecialFunc(keySpecial);
	glutReshapeFunc(reshape);	
	glutMouseFunc(mouseClik);		
	glutMotionFunc(mouseMove);

}

void init_ogl(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);	
										
	glColor3f(0.0, 0.0, 0.0);			
	glShadeModel(GL_FLAT);		
}

void init_raytrace(void)
{
	myScene.item[0].create();
    myScene.item[0].zVal = 0.0;     
    myScene.item[0].xGap = 1.0;
    myScene.item[0].yGap = 1.0;
    myScene.item[0].lineWidth = 0.1;
    myScene.item[0].rayLoadIdentity();

	myScene.item[1].createSphere(1.0);
	myScene.item[1].matlNum = 5;
	myScene.item[1].rayLoadIdentity();

	myScene.item[2].createSphere(1.0);
	myScene.item[2].matlNum = 0;
	myScene.item[2].rayLoadIdentity();

	myScene.item[3].createSphere(1.0);
	myScene.item[3].matlNum = 3;
	myScene.item[3].rayLoadIdentity();

	myScene.item[4].createSphere(1.0);
	myScene.item[4].matlNum = 4;
	myScene.item[4].rayLoadIdentity();

	myScene.item[5].createSphere(1.0);
	myScene.item[5].matlNum = 0;
	myScene.item[5].rayLoadIdentity();

	myScene.item[6].createSphere(1.0);
	myScene.item[6].matlNum = 3;
	myScene.item[6].rayLoadIdentity();

	myScene.item[7].createSphere(1.0);
	myScene.item[7].matlNum = 4;
	myScene.item[7].rayLoadIdentity();

	myScene.item[8].createSphere(1.0);
	myScene.item[8].matlNum = 5;
	myScene.item[8].rayLoadIdentity();

	myScene.item[9].createCube();
	myScene.item[9].matlNum = 6;
	myScene.item[9].rayLoadIdentity();

	myScene.matter[0].ambient[0] = 0.1745;
	myScene.matter[0].ambient[1] = 0.01175;
	myScene.matter[0].ambient[2] = 0.01175;
	myScene.matter[0].diffuse[0] = 0.61424;
	myScene.matter[0].diffuse[1] = 0.04136;
	myScene.matter[0].diffuse[2] = 0.04136;
	myScene.matter[0].specular[0] = 0.727811;
	myScene.matter[0].specular[1] = 0.626959;
	myScene.matter[0].specular[2] = 0.626959;
	myScene.matter[0].shininess = 60.0;
	myScene.matter[0].reflectivity = .2;

	myScene.matter[1].ambient[0] = 0.0;
	myScene.matter[1].ambient[1] = 0.0;
	myScene.matter[1].ambient[2] = 0.00;
	myScene.matter[1].diffuse[0] = 0.01;
	myScene.matter[1].diffuse[1] = 0.01;
	myScene.matter[1].diffuse[2] = 0.01;
	myScene.matter[1].specular[0] = 0.5;
	myScene.matter[1].specular[1] = 0.5;
	myScene.matter[1].specular[2] = 0.5;
	myScene.matter[1].shininess = 0.25;
	myScene.matter[1].reflectivity = 0.0;

	myScene.matter[2].ambient[0] = 0.0;
	myScene.matter[2].ambient[1] = 0.0;
	myScene.matter[2].ambient[2] = 0.0;
	myScene.matter[2].diffuse[0] = 0.55;
	myScene.matter[2].diffuse[1] = 0.55;
	myScene.matter[2].diffuse[2] = 0.55;
	myScene.matter[2].specular[0] = 0.7;
	myScene.matter[2].specular[1] = 0.7;
	myScene.matter[2].specular[2] = 0.7;
	myScene.matter[2].shininess = 0.25;
	myScene.matter[2].reflectivity = 0.0;

	myScene.matter[3].ambient[0] = 0.01175;
	myScene.matter[3].ambient[1] = 0.1745;
	myScene.matter[3].ambient[2] = 0.01175;
	myScene.matter[3].diffuse[0] = 0.04136;
	myScene.matter[3].diffuse[1] = 0.61424;
	myScene.matter[3].diffuse[2] = 0.04136;
	myScene.matter[3].specular[0] = 0.626959;
	myScene.matter[3].specular[1] = 0.727811;
	myScene.matter[3].specular[2] = 0.626959;
	myScene.matter[3].shininess = 60.0;
	myScene.matter[3].reflectivity = .05;

	myScene.matter[4].ambient[0] = 0.01175;
	myScene.matter[4].ambient[1] = 0.01175;
	myScene.matter[4].ambient[2] = 0.1745;
	myScene.matter[4].diffuse[0] = 0.04136;
	myScene.matter[4].diffuse[1] = 0.04136;
	myScene.matter[4].diffuse[2] = 0.61424;
	myScene.matter[4].specular[0] = 0.626959;
	myScene.matter[4].specular[1] = 0.626959;
	myScene.matter[4].specular[2] = 0.727811;
	myScene.matter[4].shininess = 60.0;
	myScene.matter[4].reflectivity = .1;

	myScene.matter[5].ambient[0] = 0.0;
	myScene.matter[5].ambient[1] = 0.0;
	myScene.matter[5].ambient[2] = 0.0;
	myScene.matter[5].diffuse[0] = 0.0;
	myScene.matter[5].diffuse[1] = 0.0;
	myScene.matter[5].diffuse[2] = 0.0;
	myScene.matter[5].specular[0] = 0.0;
	myScene.matter[5].specular[1] = 0.0;
	myScene.matter[5].specular[2] = 0.0;
	myScene.matter[5].shininess = 100.0;
	myScene.matter[5].reflectivity = 1;

	myScene.matter[6].ambient[0] = 0.01;
	myScene.matter[6].ambient[1] = 0.01;
	myScene.matter[6].ambient[2] = 0.01;
	myScene.matter[6].diffuse[0] = 0.2;
	myScene.matter[6].diffuse[1] = 0.2;
	myScene.matter[6].diffuse[2] = 0.2;
	myScene.matter[6].specular[0] = 0.7;
	myScene.matter[6].specular[1] = 0.7;
	myScene.matter[6].specular[2] = 0.7;
	myScene.matter[6].shininess = 100.0;
	myScene.matter[6].reflectivity = .3;

	myScene.lamp[0].create();
	myScene.lamp[0].I_a.put(0.25,0.25,0.25,1);
	myScene.lamp[0].I_d.put(0.35,0.35,0.35,1);
	myScene.lamp[0].I_s.put(0.35,0.35,0.35,1);
	myScene.lamp[0].pos.put(0,0,0,1);
	//myScene.lamp[0].pos.put(0,10,-4,1);

	myScene.lamp[1].create();
	myScene.lamp[1].I_a.put(0.25,0.25,0.25,1);
	myScene.lamp[1].I_d.put(0.35,0.35,0.35,1);
	myScene.lamp[1].I_s.put(0.35,0.35,0.35,1);
	myScene.lamp[1].pos.put(0,0,0,1);

	myScene.lamp[2].create();
	myScene.lamp[2].I_a.put(0.0,0.5,0.0,1);
	myScene.lamp[2].I_d.put(0.0,0.5,0.0,1);
	myScene.lamp[2].I_s.put(0.0,0.5,0.0,1);
	myScene.lamp[2].pos.put(0,0,0,1);
	
}

void reshape(int w, int h)
{
GLdouble cAspect;					
GLdouble cTop,cBot,cLeft,cRight,cNear;
Vec4 cVRP,cVUP;                  	
Vec4 cLookAtPt;						
	
	viewportW = w/2;					
	viewportH = h;						
	glViewport(0, 0, viewportW, viewportH);
	cAspect = (GLdouble)viewportW / (GLdouble)viewportH;

	glMatrixMode(GL_PROJECTION);


    setModel.reset();       
    setModel.pos[2] = -5.0; 

    cLeft = -1.0; cRight = 1.0;
    cBot = -1.0;    cTop = 1.0;
    cNear = JT_ZNEAR;
	
	glLoadIdentity();		
	glFrustum(				
		cLeft,    cRight,	
		cBot,     cTop,		
		cNear, JT_ZFAR);	



	myScene.rayCam.setFrustum(cLeft,cRight,cBot,cTop,cNear,viewportW,viewportH);

	myPic.resetSize(viewportW, viewportH);	
	myPic.clear(0.9,0.4,0.1);			
										
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();					
}

void display(void)
{
	glViewport(0, 0, (GLsizei) viewportW, (GLsizei) viewportH);

	glClearColor(0.0, 0.0, 0.0, 0.0);	
	glClear(GL_COLOR_BUFFER_BIT);

// =============================================================================
// START LEFT-SIDE DRAWING CODE HERE
// =============================================================================
	glMatrixMode(GL_PROJECTION);	
	glPushMatrix();					
	glGetDoublev(GL_PROJECTION_MATRIX,pViewMat);
									
	glMatrixMode(GL_MODELVIEW);		
	glPushMatrix();					

	glLoadIdentity();                  
	myScene.item[0].rayLoadIdentity();  
	myScene.item[1].rayLoadIdentity();
	myScene.item[2].rayLoadIdentity();
	myScene.item[3].rayLoadIdentity();
	myScene.item[4].rayLoadIdentity();
	myScene.item[5].rayLoadIdentity();
	myScene.item[6].rayLoadIdentity();
	myScene.item[7].rayLoadIdentity();
	myScene.item[8].rayLoadIdentity();
	myScene.item[9].rayLoadIdentity();
	
	myScene.lamp[0].rayLoadIdentity();
	myScene.lamp[1].rayLoadIdentity();
	myScene.lamp[2].rayLoadIdentity();
	
    setModel.drawAxes(0);               

	setModel.applyMatrix();	        

    setModel.applyRayMatrix(myScene.item[0]);
	setModel.applyRayMatrix(myScene.item[1]);
	setModel.applyRayMatrix(myScene.item[2]);
	setModel.applyRayMatrix(myScene.item[3]);
	setModel.applyRayMatrix(myScene.item[4]);
	setModel.applyRayMatrix(myScene.item[5]);
	setModel.applyRayMatrix(myScene.item[6]);
	setModel.applyRayMatrix(myScene.item[7]);
	setModel.applyRayMatrix(myScene.item[8]);
	setModel.applyRayMatrix(myScene.item[9]);

	setModel.applyRayMatrix(myScene.lamp[0]);
	setModel.applyRayMatrix(myScene.lamp[1]);
	setModel.applyRayMatrix(myScene.lamp[2]);
                                    
	glGetDoublev(GL_MODELVIEW_MATRIX,pModelMat);
	

    
	myScene.item[0].drawOpenGL();   // draw scene in openGL.

	glPushMatrix();
	glTranslated(5,-5,10);
	myScene.lamp[0].rayTranslate3d(5,-5,10);
	glPopMatrix();

	glPushMatrix();
	glTranslated(-5,0,20);
	myScene.lamp[1].rayTranslate3d(-5,0,20);
	glPopMatrix();

	glPushMatrix();
	myScene.lamp[2].rayTranslate3d(0,0,5);
	glPopMatrix();

	//glEnable(GL_LIGHTING);
	glShadeModel(GL_SMOOTH);
	
	glPushMatrix();
	glTranslated(2,2,1.5);
	glScaled(1.5,1.5,1.5);
	myScene.item[1].rayTranslate3d(2,2,1.5);
	myScene.item[1].rayScale3d(1.5,1.5,1.5);
	myScene.item[1].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(-2,2,1.5);
	glScaled(1.5,1.5,1.5);
	myScene.item[2].rayTranslate3d(-2,2,1.5);
	myScene.item[2].rayScale3d(1.5,1.5,1.5);
	myScene.item[2].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(3,0,.5);
	glScaled(.5,.5,.5);
	myScene.item[3].rayTranslate3d(3,0,.5);
	myScene.item[3].rayScale3d(.5,.5,.5);
	myScene.item[3].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(1,0,.5);
	glScaled(.5,.5,.5);
	myScene.item[4].rayTranslate3d(1,0,.5);
	myScene.item[4].rayScale3d(.5,.5,.5);
	myScene.item[4].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(-1,0,.5);
	glScaled(.5,.5,.5);
	myScene.item[8].rayTranslate3d(-1,0,.5);
	myScene.item[8].rayScale3d(.5,.5,.5);
	myScene.item[8].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(-3,0,.5);
	glScaled(.5,.5,.5);
	myScene.item[5].rayTranslate3d(-3,0,.5);
	myScene.item[5].rayScale3d(.5,.5,.5);
	myScene.item[5].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(-2,-2,.25);
	glScaled(.25,.25,.25);
	myScene.item[6].rayTranslate3d(-2,-2,.25);
	myScene.item[6].rayScale3d(.25,.25,.25);
	myScene.item[6].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(2,-2,.25);
	glScaled(.25,.25,.25);
	myScene.item[7].rayTranslate3d(2,-2,.25);
	myScene.item[7].rayScale3d(.25,.25,.25);
	myScene.item[7].drawOpenGL();
	glPopMatrix();

	glPushMatrix();
	glTranslated(0,-2,.5);
	glRotated(45,0,0,1);
	glScaled(.5,.5,.5);
	myScene.item[9].rayTranslate3d(0,-2,.5);
	myScene.item[9].rayRotate3d(45,0,0,1);
	myScene.item[9].rayScale3d(.5,.5,.5);
	myScene.item[9].drawOpenGL();
	glPopMatrix();


	glPopMatrix();				
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	// ================================================================================
	// END LEFT-SIDE DRAWING CODE HERE
	// ================================================================================

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();			
	glViewport((GLsizei) viewportW,0, (GLsizei)viewportW,(GLsizei) viewportH);
								
	gluOrtho2D(0, viewportW/2, 0, viewportH);
							
	// =========================================================================
	// START RIGHT-SIDE DRAWING CODE HERE
	// =========================================================================
						
	myPic.displayMe(0,0);

	glPopMatrix();			
// ============================================================================
// END RIGHT-SIDE DRAWING CODE HERE
// =============================================================================
	glFlush();                         
    glutSwapBuffers();                 

}

void keyboard(unsigned char key, int x, int y)
{

	switch(key)
	{
		case 27: // Esc
		case 'Q':
		case 'q':
			exit(0);		
			break;
		case 'r':
		case 'R':			
			setModel.reset();
			setModel.pos[2] = -5.0;
			cout << "GL_MODELVIEW matrix reset" << endl;
			break;

		case 'm':			
		case'M':
			printf("\n Current value of GL_PROJECTION matrix:\n");
			printf("%f \t %f \t %f \t %f\n",
					pViewMat[0], pViewMat[4], pViewMat[8], pViewMat[12] );
			printf("%f \t %f \t %f \t %f\n",
					pViewMat[1], pViewMat[5], pViewMat[9], pViewMat[13] );
			printf("%f \t %f \t %f \t %f\n",
					pViewMat[2], pViewMat[6], pViewMat[10],pViewMat[14] );
			printf("%f \t %f \t %f \t %f\n",
					pViewMat[3], pViewMat[7], pViewMat[11],pViewMat[15] );

			printf("\n Current value of GL_MODELVIEW matrix:\n");
			printf("%f \t %f \t %f \t %f\n",
					pModelMat[0], pModelMat[4], pModelMat[8], pModelMat[12] );
			printf("%f \t %f \t %f \t %f\n",
					pModelMat[1], pModelMat[5], pModelMat[9], pModelMat[13] );
			printf("%f \t %f \t %f \t %f\n",
					pModelMat[2], pModelMat[6], pModelMat[10],pModelMat[14] );
			printf("%f \t %f \t %f \t %f\n",
					pModelMat[3], pModelMat[7], pModelMat[11],pModelMat[15] );
			break;

		case 't':		
		case 'T':

            myScene.makeRayTracedImage(myPic,30);
//			glutIdleFunc(callMyTracer); // register ray-tracer so it gets
						// all unused compute time.  We'll 'unregister' it
						// when the ray-tracing is done.
//			myScene.rayCam.xNow = 0;// Go start of image:  callMyTracer() will
//			myScene.rayCam.yNow = 0;// make pixels until we fill the image.
			break;

		case 'c':
		case 'C':		
			myPic.clear(0.8, 0.8,0.3);

			break;

		case 'a':      
        case 'A':
           if(myScene.isAA==true)
            {
                myScene.isAA = false;
                cout << "\n AntiAliasing turned OFF.\n" << endl;
            }
            else
            {
                myScene.isAA = true;
                cout << "\n AntiAliasing turned ON:"
                     << myScene.xSuperAA << " x " << myScene.ySuperAA
                     << "jittered super-sampling\n" << endl;
            }
            break;

        case 'd':   // INCREASE recursion depth.
                myScene.depthMax++;
                printf("\nRecursion Depth MAX set to %d\n",myScene.depthMax);
            break;
        case 'D':   // DECREASE recursion depth, but keep it >=0.
                myScene.depthMax--;
                if(myScene.depthMax < 0) myScene.depthMax = 0;
                printf("\nRecursion Depth MAX set to %d\n",myScene.depthMax);
            break;

        case '+':
        case '=':   // ( '+' sign without shift key)
            setModel.pos[2] += 0.5; // change z position
            break;
        case '-':
            setModel.pos[2] -= 0.5; // change z position
            break;

		default:
			printf("unknown key.  Try arrow keys, R,r,m,t,c or q");
			break;
	}
	glutPostRedisplay();
}

void keySpecial(int key, int x, int y)
{
static double x_pos, y_pos;

	switch(key)
	{
		case GLUT_KEY_LEFT:		
			setModel.pos[0] -= 0.1;
			break;
		case GLUT_KEY_RIGHT:	
			setModel.pos[0] += 0.1;
			break;
		case GLUT_KEY_DOWN:		
			setModel.pos[1] -= 0.1;
			break;
		case GLUT_KEY_UP:		
			setModel.pos[1] += 0.1;
			break;
		default:
			break;
	}
	printf("key=%d, setModel.x_pos=%f, setModel.y_pos=%f\n",
               key, setModel.pos[0],   setModel.pos[1]);

	glutPostRedisplay();
}

void mouseClik(int buttonID,int upDown,int xpos, int ypos)
{
	if(buttonID==0)				
	{
		if(upDown==0)
		{
			setModel.isDragging = 1;
			setModel.m_x = xpos;	
			setModel.m_y = ypos;
		}
		else setModel.isDragging = 0;
	}
	else if(buttonID==2)		
	{
        
	}
	else						
	{
		setModel.isDragging = 0;	
	}
}

void mouseMove(int xpos,int ypos)
{

	if(setModel.isDragging==1)		
	{								
		setModel.rotDragTo(xpos,ypos);
	}

	glutPostRedisplay();
}

void callMyTracer(void)
{
    // Wipe any previously traced image (*NOT NECESSARY!*);
    myPic.clear(0.0, 1.0, 0.0);
	// have we just finished an image?
    // if(myScene.rayCam.yNow >= myPic.ysize)
	{		// Yes!
		glutIdleFunc(NULL);		// un-register us; don't call us anymore when
								// the Windows system is idle.
		printf("Finished Ray Tracing!\n");
	}
	// Not done--so let's
//	myScene.makeRayTracedImage(myPic, 30);     // trace 30 scanlines or so.
	glutPostRedisplay();	                   // show what we've done.
}

//==============================================================================
//3456789_123456789_123456789_123456789_123456789_123456789_123456789_123456789_
//  CTransRot
//	Mouse- and keyboard-controlled class for rigid-body transforms used in
//	OpenGL/GLUT projects.
//
//	01/06/2005 J. Tumblin -- Created.
//  02/07/2006 J. Tumblin -- mild improvements to ApplyMatrix(); added rotDragTo
//				and transDragTo functions.
//==============================================================================

#define JT_INCR 1.0					// Degrees rotation per pixel of mouse move
CTransRot::~CTransRot(void)
//------------------------------------------------------------------------------
// Default destructor
{
}

CTransRot::CTransRot(void)
//------------------------------------------------------------------------------
// Default constructor
{
	reset();						// set all values to zero.
}

void CTransRot::reset(void)
//------------------------------------------------------------------------------
// Set all values to zero.
{
int i;

	for(i=0; i<3; i++)
	{
		pos[i] = 0.0;
		rot[i] = 0.0;
	}
}

void CTransRot::rotDragTo(int xNew, int yNew)
//------------------------------------------------------------------------------
// Find rotations from mouse dragging. Mouse was dragged from m_x, m_y to
// xNew,yNew on-screen; apply additional rotation to our m_matrix.
{

	rot[0] += JT_INCR*(xNew - m_x);	// update the rotation amounts
	rot[1] += JT_INCR*(yNew - m_y);	//
	m_x = xNew;						// update the start position for dragging.
	m_y = yNew;
}

void CTransRot::transDragTo(int xNew, int yNew)
//------------------------------------------------------------------------------
// Find translations from mouse dragging. Mouse was dragged from m_x,m_y to
// xNew,yNew on-screen; apply additional translation to our m_matrix.
{
	pos[0] += JT_INCR*(xNew - m_x);	// update the translation amounts
	pos[1] += JT_INCR*(yNew - m_y);
	m_x = xNew;						// Update the start position for dragging.
	m_y = yNew;
}


void CTransRot::applyMatrix(void)
//------------------------------------------------------------------------------
// Apply rotations, then translations to the coordinate axes.
// (Note OpenGL pre-multiplies matrices,
//   so commands may appear to be in reverse order).
//
// (NOTE!!!! A RayTracer may transform the RAYS to the OBJECTS; if so, they
// need the INVERSE of the matrix used by openGL!!!
// HINT: try writing separate functions for each, e.g.
// applyOpenGLmatrix() and applyTracerMatrix() functions
//
{
GLdouble angl;

	glTranslated(pos[0], pos[1], pos[2]);	// translate by mouse offset amount

	angl =rot[0]*rot[0] + rot[1]*rot[1];	// mouse displacement distance
	angl = sqrt(angl);
			// (HINT: want mouse acceleration? just drop the square root!)
	glRotated(angl, rot[1], rot[0], 0.0);	// on-screen rotation:
			// approximate a 'trackball' for rotation:
			// mouse drag in y direction rotates about x axis on-screen, and
			// mouse drag in x direction rotates about y axis on-screen.
}


void CTransRot::applyRayMatrix(CGeom& dest)
//------------------------------------------------------------------------------
// Apply the same rotations & translations we used in applyMatrix() to
// a ray-traced object's **EXISTING** worldRay2model matrix.
// Just as openGL supplies us with glTranslate(),glRotate(), glScale(), our
// CGeom ray-tracing class has rayTranslate3d(),rayRotate3d(), rayScale3d()
// member functions that take the same arguments.
// **CAREFUL! you'll probably want to call CGeom::rayLoadIdentity() first!!!
{
GLdouble angl;


   dest.rayTranslate3d(pos[0], pos[1], pos[2]);    // translate by mouse offset

	angl =rot[0]*rot[0] + rot[1]*rot[1];	// mouse displacement distance
	angl = sqrt(angl);
	dest.rayRotate3d(angl, rot[1],rot[0], 0.0);
			// approximate a 'trackball' for rotation:
			// mouse drag in y direction rotates about x axis on-screen, and
			// mouse drag in x direction rotates about y axis on-screen.

}

void CTransRot::applyRayMatrix(CLight& dest)
//------------------------------------------------------------------------------
// My modification --Ryan
{
GLdouble angl;


   dest.rayTranslate3d(pos[0], pos[1], pos[2]);    // translate by mouse offset

	angl =rot[0]*rot[0] + rot[1]*rot[1];	// mouse displacement distance
	angl = sqrt(angl);
	dest.rayRotate3d(angl, rot[1],rot[0], 0.0);
			// approximate a 'trackball' for rotation:
			// mouse drag in y direction rotates about x axis on-screen, and
			// mouse drag in x direction rotates about y axis on-screen.

}

void CTransRot::drawAxes(int colr)
//------------------------------------------------------------------------------
// Draw 3D axes in the current coordinate system.
//  The 'colr' value (0,1,2,3,etc.) selects a distinctive color scheme to make
//  co-located axes easily distinguishable.
{
GLfloat xcolr[3],ycolr[3],zcolr[3];
    switch(colr)
    {
        case 0:
            xcolr[0] = 1.0; xcolr[1] = 0.0; xcolr[2] = 0.0; // x = red
            ycolr[0] = 0.0; ycolr[1] = 1.0; ycolr[2] = 0.0; // y = green
            zcolr[0] = 0.0; zcolr[1] = 0.0; zcolr[2] = 1.0; // z = blue.
            break;
        case 1:
            xcolr[0] = 1.0; xcolr[1] = 1.0; xcolr[2] = 0.0; // x = yellow
            ycolr[0] = 0.0; ycolr[1] = 1.0; ycolr[2] = 1.0; // y = cyan
            zcolr[0] = 1.0; zcolr[1] = 0.0; zcolr[2] = 1.0; // z = purple
            break;
        case 2:
            xcolr[0] = 1.0; xcolr[1] = 0.6; xcolr[2] = 0.6; // x = light-red
            ycolr[0] = 0.6; ycolr[1] = 1.0; ycolr[2] = 0.6; // y = light-green
            zcolr[0] = 0.6; zcolr[1] = 0.6; zcolr[2] = 1.0; // z = light-blue
            break;
        case 3:
        default:
            xcolr[0] = 1.0; xcolr[1] = 1.0; xcolr[2] = 1.0; // x = white
            ycolr[0] = 1.0; ycolr[1] = 1.0; ycolr[2] = 1.0; // y = white
            zcolr[0] = 0.0; zcolr[1] = 1.0; zcolr[2] = 0.0; // z = green
            break;
    }
	glBegin(GL_LINES);				// draw axes in model-space.
		glColor3fv (xcolr);	        // X axis
		glVertex3f( 0.0, 0.0, 0.0);
		glVertex3f( 1.0, 0.0, 0.0);

		glColor3fv(ycolr);	        // Y axis
		glVertex3f( 0.0, 0.0, 0.0);
		glVertex3f( 0.0, 1.0, 0.0);

		glColor3fv(zcolr);	        // Z axis
		glVertex3f( 0.0, 0.0, 0.0);
		glVertex3f( 0.0, 0.0, 1.0);
	glEnd();
}

#undef JT_INCR


