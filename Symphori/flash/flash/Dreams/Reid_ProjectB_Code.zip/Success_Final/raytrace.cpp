#include "raytrace.h"		

//==============================
//
//  CRay member functions
//
//==============================

CRay::~CRay(void)
 //-----------------------------------------------------------------------------
 // default destructor
 {
 }

CRay::CRay(void)
//------------------------------------------------------------------------------
// default constructor
{
		orig.zero();			// make ray start at origin
		orig.row[3] = 1.0;		// it's a point, not a vector; set w to 1.0.
		dir.zero();
		dir.row[0]= 1.0;		// make ray point in +x direction.
}

//==============================
//
//  CRayHit member functions
//
//==============================
CRayHit::CRayHit(void)
//------------------------------------------------------------------------------
// Default Constructor
{
}

CRayHit::~CRayHit(void)
//------------------------------------------------------------------------------
// Default Destructor
{
}


//==============================
//
//  CImageBuf member functions
//
//==============================

CImageBuf::~CImageBuf(void)
//------------------------------------------------------------------------------
// Default destructor
{
	kill();						// destroy the buffer & its contents.
}

CImageBuf::CImageBuf(void)
//------------------------------------------------------------------------------
// Default constructor
{
	xSize = 0;					// empty and
	ySize = 0;
	pBuffer = NULL;				// pointing to nothing.
}


void CImageBuf::resetSize(int newXsize, int newYsize)
//------------------------------------------------------------------------------
// Check the current buffer size. If it isn't nuXsize,nuYsize, discard the
// buffer and make a new one of that size.
{
	if(newXsize!=xSize || newYsize!=ySize)	// is there a size mismatch?
	{
        kill();							    // destroy the buffer, and
		pBuffer = new GLfloat[3*newXsize*newYsize];	// make a new one.
		xSize = newXsize;
		ySize = newYsize;

	}
}

void CImageBuf::kill(void)
//------------------------------------------------------------------------------
// Destroy the contents of the buffer and discard the memory it uses.
{
	if(xSize!=0 && ySize!=0 && pBuffer!=NULL)	// if we've got a buffer,
	{
		delete pBuffer;					// delete it's memory.
		pBuffer = NULL;					// Point to nothing.
	}
	xSize = 0;
	ySize = 0;
}

void CImageBuf::clear(GLfloat r, GLfloat g, GLfloat b)
//------------------------------------------------------------------------------
// Fill the entire buffer with one color.
{
int i,imax;

	imax = xSize*ySize*3;				// # of pixels in buffer
	for(i=0; i<imax; i+=3)				// fill them all
	{
		pBuffer[i  ] = r;
		pBuffer[i+1] = g;
		pBuffer[i+2] = b;
	}
}

void CImageBuf::drawGrid(int xgap, int ygap)
//------------------------------------------------------------------------------
// Draw a grid in the frame buffer; spacing in x,y set by xgap, ygap.
{
int i,j, xLine,yLine;
GLfloat lineColr[] = {0.0, 0.0, 0.0};   // line-drawing color;
GLfloat gapColr[] = {1.0, 1.0, 1.0};    // color between gaps.


    xLine =  xgap/10;        // line width is 1/10th of grid spacing
    yLine =  ygap/10;
    for(j=0; j<ySize; j++)
    {
        for(i=0; i<xSize; i++)  // at pixel i of scanline j,
        {
            // if i,j is NOT part of a line
            if( (i%xgap > xLine) &&
                (j%ygap > yLine))
                    put(i,j,gapColr);  // draw non-line color
            else    put(i,j,lineColr);  // otherwise, draw the line color.
        }
    }
}

void CImageBuf::put(int x, int y, GLfloat* pRGB)
//------------------------------------------------------------------------------
// Set the pixel value at x,y to RGB = ( pRGB[0], pRGB[1], pRGB[2]).
{
int i;

	for(i=0; i<3; i++) pBuffer[(x + y*xSize)*3 + i] = pRGB[i];
}

void CImageBuf::put(int x, int y, GLfloat r, GLfloat g, GLfloat b)
//------------------------------------------------------------------------------
// Set the pixel value at x,y to r,g,b.
{
int i;

	i = (x + y*xSize)*3;
	pBuffer[i] =   r;
	pBuffer[i+1] = g;
	pBuffer[i+2] = b;
}

void CImageBuf::displayMe(int xorig, int yorig)
//------------------------------------------------------------------------------
// Display this buffer on-screen with its lower-left corner at xorig,yorig.
// (call this from your openGL 'display()' callback)
{
	glRasterPos2i(xorig, yorig);
	glDrawPixels(xSize,ySize,GL_RGB,GL_FLOAT,pBuffer);
}

//==============================
//
//  CCamera member functions
//
//==============================

CCamera::CCamera(void)
//------------------------------------------------------------------------------
// default constructor
{

}

CCamera::~CCamera(void)
//-----------------------------------------------------------------------------
// default destructor
{

}

void CCamera::setFrustum(GLdouble left, GLdouble right,
                          GLdouble bot,  GLdouble top, GLdouble GLnear,
                          int xsize, int ysize)
//------------------------------------------------------------------------------
// set viewing frustum with the same parameters used by openGL's glFrustum().
// Usually called in GLUT's 'reshape()' callback, where we adjust the openGL
// camera as well to match the changed display window.
// GOTCHA!! OpenGL uses POSITIVE values for znear, zfar, but we need
//      NEGATIVE ones for our ray-tracing camera: we need z = -znear!
{
    imgLeft = left; imgRight = right;
    imgBot = bot; imgTop = top;
    zNear = -GLnear;
    xPixels = xsize; yPixels = ysize;
}

void CCamera::makeEyeRay(CRay *pEye, GLdouble xpos, GLdouble ypos)
//------------------------------------------------------------------------------
// Create a ray from eyepoint through the image plane at pixel xpos,ypos.
{
    pEye->orig.row[0] = 0.0;    // start every ray from the origin,
    pEye->orig.row[1] = 0.0;
    pEye->orig.row[2] = 0.0;
    pEye->orig.row[3] = 1.0;    // because orig is a point.

    pEye->dir.row[0] = xpos  - pEye->orig.row[0];
    pEye->dir.row[1] = ypos  - pEye->orig.row[1];
    pEye->dir.row[2] = zNear - pEye->orig.row[2];
    pEye->dir.row[3] = 0.0; // because dir is a vector.
}

//==============================
//
//  CGeom member functions
//
//==============================

CGeom::~CGeom(void)
//-----------------------------------------------------------------------------
// default destructor
{
    isAlive = false;            // ignore this shape.
}

CGeom::CGeom(void)
//------------------------------------------------------------------------------
// default constructor
{
    isAlive = false;            // ignore this shape.
	shapeType = JT_GRID;
    rayLoadIdentity();          // set ray transformation to 'do-nothing'
}

void CGeom::drawOpenGL(void)
//------------------------------------------------------------------------------
// Draw this object in the current coordinate system in openGL.
{
	int i;
	#define JT_PLANE_SIZE  20.0     // how far to extend grid from origin.

	switch(shapeType) {
		case JT_BOX:
			glutSolidCube(2);
		break;

		case JT_SPHERE:
			glutSolidSphere(radius,15,15);
		break;
		
		default:
			glColor3d(1.0, 1.0, 1.0);   // white lines:
			for(i=-20; i<20; i++)
			{                           // draw lines perpendicular to x axis:
				glBegin(GL_LINES);
					glVertex3d(i*xGap, -JT_PLANE_SIZE, zVal);
					glVertex3d(i*xGap,  JT_PLANE_SIZE, zVal);
				glEnd();
				glBegin(GL_LINES);
					glVertex3d(-JT_PLANE_SIZE, i*yGap, zVal);
					glVertex3d( JT_PLANE_SIZE, i*yGap, zVal);
				glEnd();
			}
		break;
	}
}



void CGeom::createSphere(double r) {
	shapeType = JT_SPHERE;
	radius = r;
	isAlive = true;
}

void CGeom::createCube() {
	shapeType = JT_BOX;
	isAlive = true;
}

void CGeom::rayLoadIdentity(void)
//------------------------------------------------------------------------------
// clear current contents of worldRay2model matrix; set to I matrix
{
    worldRay2model.ident();
}

void CGeom::rayTranslate3d(GLdouble tx, GLdouble ty, GLdouble tz)
//------------------------------------------------------------------------------
// translate the object's current coord sys by INVERSE of tx,ty,tz;
// post-multiplies the worldRay2model matrix with translation matrix
//  [new] = [T^-1][current]
{
	Mat4 mTran;

    mTran.ident();
    mTran.colrow[3][0] = -tx;    // build translation matrix,
    mTran.colrow[3][1] = -ty;
    mTran.colrow[3][2] = -tz;    // post-multiply current contents

    worldRay2model.mmpy(mTran, worldRay2model);

//worldRay2model.prnt();

}

void CGeom::rayRotate3d(GLdouble deg, GLdouble x, GLdouble y, GLdouble z)
//------------------------------------------------------------------------------
// Rotate the object's current coord system by INVERSE of deg degrees around
// the vector axis  given by (x,y,z).  Post-multiplies the current
// worldRay2model matrix with the rotation matrix [R^-1].
//      [new] = [R^-1][current]
// We find the matrix in exactly the same way that openGL does it, but we
// NEGATE the 'deg' value so that we find the inverse matrix.
{
	Mat4 mRot;
	GLdouble c,s;       // cosine, sine of -deg;
	GLdouble len2;       // squared length of x,y,z vector.


    // is (x,y,z) a unit-length vector?
    len2 = x*x + y*y + z*z;
    if(len2 != 1.0)
    {
        if(len2 < 10E-15)
        {
  //          cout << "\n CGeom::rayRotate3d() given zero-length vector!!\n" <<endl;
            return;     // do nothing!
        }
        len2 = sqrt(len2);      // find actual vector length, then
        x = x/len2;             // normalize the vector.
        y = y/len2;
        z = z/len2;
    }

    c = (GLdouble)cos(-deg*M_PI / 180.0);    // find cosine(-deg) in degrees
    s = (GLdouble)sin(-deg*M_PI / 180.0);    // find sine (-deg) in degrees
    // using -deg instead of deg will create an inverse-rotation matrix, so
    // the rest is the same matrix transform used in openGL
    //  http://www.talisman.org/opengl-1.1/Reference/glRotate.html
    mRot.ident();       // start clean
    mRot.colrow[0][0] = x*x*(1.0 - c) + c;
    mRot.colrow[0][1] = y*x*(1.0 - c) + z*s;
    mRot.colrow[0][2] = z*x*(1.0 - c) - y*s;

    mRot.colrow[1][0] = x*y*(1.0 - c) - z*s;
    mRot.colrow[1][1] = y*y*(1.0 - c) + c;
    mRot.colrow[1][2] = z*y*(1.0 - c) + x*s;

    mRot.colrow[2][0] = x*z*(1.0 - c) + y*s;
    mRot.colrow[2][1] = y*z*(1.0 - c) - x*s;
    mRot.colrow[2][2] = z*z*(1.0 - c) + c;

    worldRay2model.mmpy(mRot, worldRay2model);   //POST-multiply.

}

void CGeom::rayScale3d(GLdouble sx, GLdouble sy, GLdouble sz)
//------------------------------------------------------------------------------
// Scale the object's current coord system by the INVERSE of sx,sy,sz.
// Post-multiplies the current contents of worldRay2model matrix with scale
// matrix [S^-1]:
// [new] = [S^-1][current]
{
Mat4 mScl;

    mScl.ident();     // construct inverse scaling matrix
    mScl.colrow[0][0] = 1.0 / sx;
    mScl.colrow[1][1] = 1.0 / sy;
    mScl.colrow[2][2] = 1.0 / sz;
    worldRay2model.mmpy(mScl, worldRay2model);    // POST-multiply.
}


//==============================
//
//  CMatl member functions
//
//==============================

CMatl::CMatl(void)
//-----------------------------------------------------------------------------
// Default constructor; make a dull-gray Phong-lit material.
{

 //   index = 1.0;                // default index of refraction == air.
}

CMatl::~CMatl(void)
//-----------------------------------------------------------------------------
// Default destructor.
{

}

//==============================
//
//  CLight member functions
//
//==============================
CLight::CLight(void)
//------------------------------------------------------------------------------
// default constructor.
{
    isAlive = false;            // ignore this light.
}

CLight::~CLight(void)
//------------------------------------------------------------------------------
// default destructor.
{
    isAlive = false;            // ignore this light.
}

void CLight::rayLoadIdentity(void)
//------------------------------------------------------------------------------
// clear current contents of worldRay2model matrix; set to I matrix
{
    worldRay2model.ident();
}

void CLight::rayTranslate3d(GLdouble tx, GLdouble ty, GLdouble tz)
//------------------------------------------------------------------------------
// translate the object's current coord sys by INVERSE of tx,ty,tz;
// post-multiplies the worldRay2model matrix with translation matrix
//  [new] = [T^-1][current]
{
	Mat4 mTran;

    mTran.ident();
    mTran.colrow[3][0] = -tx;    // build translation matrix,
    mTran.colrow[3][1] = -ty;
    mTran.colrow[3][2] = -tz;    // post-multiply current contents

    worldRay2model.mmpy(mTran, worldRay2model);

}

void CLight::rayRotate3d(GLdouble deg, GLdouble x, GLdouble y, GLdouble z)
//------------------------------------------------------------------------------
// Rotate the object's current coord system by INVERSE of deg degrees around
// the vector axis  given by (x,y,z).  Post-multiplies the current
// worldRay2model matrix with the rotation matrix [R^-1].
//      [new] = [R^-1][current]
// We find the matrix in exactly the same way that openGL does it, but we
// NEGATE the 'deg' value so that we find the inverse matrix.
{
	Mat4 mRot;
	GLdouble c,s;       // cosine, sine of -deg;
	GLdouble len2;       // squared length of x,y,z vector.


    // is (x,y,z) a unit-length vector?
    len2 = x*x + y*y + z*z;
    if(len2 != 1.0)
    {
        if(len2 < 10E-15)
        {
  //          cout << "\n CGeom::rayRotate3d() given zero-length vector!!\n" <<endl;
            return;     // do nothing!
        }
        len2 = sqrt(len2);      // find actual vector length, then
        x = x/len2;             // normalize the vector.
        y = y/len2;
        z = z/len2;
    }

    c = (GLdouble)cos(-deg*M_PI / 180.0);    // find cosine(-deg) in degrees
    s = (GLdouble)sin(-deg*M_PI / 180.0);    // find sine (-deg) in degrees
    // using -deg instead of deg will create an inverse-rotation matrix, so
    // the rest is the same matrix transform used in openGL
    //  http://www.talisman.org/opengl-1.1/Reference/glRotate.html
    mRot.ident();       // start clean
    mRot.colrow[0][0] = x*x*(1.0 - c) + c;
    mRot.colrow[0][1] = y*x*(1.0 - c) + z*s;
    mRot.colrow[0][2] = z*x*(1.0 - c) - y*s;

    mRot.colrow[1][0] = x*y*(1.0 - c) - z*s;
    mRot.colrow[1][1] = y*y*(1.0 - c) + c;
    mRot.colrow[1][2] = z*y*(1.0 - c) + x*s;

    mRot.colrow[2][0] = x*z*(1.0 - c) + y*s;
    mRot.colrow[2][1] = y*z*(1.0 - c) - x*s;
    mRot.colrow[2][2] = z*z*(1.0 - c) + c;

    worldRay2model.mmpy(mRot, worldRay2model);   //POST-multiply.

}

void CLight::rayScale3d(GLdouble sx, GLdouble sy, GLdouble sz)
//------------------------------------------------------------------------------
// Scale the object's current coord system by the INVERSE of sx,sy,sz.
// Post-multiplies the current contents of worldRay2model matrix with scale
// matrix [S^-1]:
// [new] = [S^-1][current]
{
Mat4 mScl;

    mScl.ident();     // construct inverse scaling matrix
    mScl.colrow[0][0] = 1.0 / sx;
    mScl.colrow[1][1] = 1.0 / sy;
    mScl.colrow[2][2] = 1.0 / sz;
    worldRay2model.mmpy(mScl, worldRay2model);    // POST-multiply.
}

//==============================
//
//  CScene member functions
//
//==============================

CScene::CScene(void)
//------------------------------------------------------------------------------
// Default constructor; makes a simple scene with a Phong-lit shiny-red sphere.
{

    xSuperAA = 4;       // initial choice: 4x4 super-sampling.
    ySuperAA = 4;
	depthMax = 1;
	bkgndColr[0] = 0.3; bkgndColr[1] = 0.3; bkgndColr[2] = 0.9;

}


CScene::~CScene(void)
//------------------------------------------------------------------------------
// Default destructor.
{

}


void CScene::makeRayTracedImage(CImageBuf& myPic, int scanCount)
//-----------------------------------------------------------------------------
// Make a ray-traced image in a CImageBuf object.
{
int i,j, k;
CRayHit hit, tempHit;
int ii,jj;      // super-sampling counters for antialiasing.

GLdouble ustep,vstep, uustep, vvstep;
GLdouble ubegin, vbegin;
GLdouble xray,yray, xjit,yjit;
GLfloat colr[3];        // Color accumulator for super-sampling

    // Size of the 'tiny squares' whose centers are the pixel locations
    ustep = (rayCam.imgRight - rayCam.imgLeft) / myPic.xSize;
    vstep = (rayCam.imgTop - rayCam.imgBot) / myPic.ySize;

    if(isAA==false) // NO antialiasing...
    {
        ubegin = rayCam.imgLeft + 0.5*ustep;
        vbegin = rayCam.imgBot + 0.5*vstep;
        for(j=0; j< myPic.ySize; j++)   // for each row of the image,
        {
            for(i=0; i<myPic.xSize; i++)    // for each column of the image,
            {
				if (i == myPic.xSize/2 && j == myPic.ySize/2) {
					cout << "HERE" << endl;
				}
                xray = ubegin + i*ustep;    // find ray thru center of
                yray = vbegin + j*vstep;    // each pixel's 'little square'
                rayCam.makeEyeRay(&rayNow,xray,yray);
                // Now trace that ray:
				hit = trace(rayNow,0);
				
				colr[0] = hit.colr[0]; colr[1] = hit.colr[1]; colr[2] = hit.colr[2];
                myPic.put(i,j, colr);
            }
        }
        return;     // DONE!
    }
    // Otherwise, use antialiasing!
    ubegin = rayCam.imgLeft;  // start at lower-left corner of image;
    vbegin = rayCam.imgBot;
    // RECALL 'ustep' and 'vstep' are width of the 'little square' for this pixel
    uustep = ustep / xSuperAA;  // the super-sampling tile width within it;
    vvstep = vstep / ySuperAA;  // the super-sampling tile height within it;

    for(j=0; j< myPic.ySize; j++)   // for each row of the image,
    {
        for(i=0; i<myPic.xSize; i++)
        {   // For each pixel,
            colr[0] = colr[1] = colr[2] = 0.0;  // clear the color accumulator
            for(jj=0; jj<ySuperAA; jj++)    // for each row of tiles in the pixel
            {

                for(ii=0; ii<xSuperAA; ii++)    // for each column of tiles ...
                {
                    // find the corner of the super-sampling 'little tile'
                    // within our our pixel's 'little square':
                    xray = ubegin + i*ustep + ii*uustep;
                    yray = vbegin + j*vstep + jj*uustep;
                    // then add jittering: random position within that tile:
                    xray += (uustep*rand())/RAND_MAX;
                    yray += (vvstep*rand())/RAND_MAX;
                    // create the jittered super-sampling ray;
                    rayCam.makeEyeRay(&rayNow,xray,yray);
                    // Now trace that ray:
                    hit = trace(rayNow,0);
				
					colr[0] += hit.colr[0]; colr[1] += hit.colr[1]; colr[2] += hit.colr[2];
                }
            }
            // find average color of all this pixel's rays:
            colr[0] /= (xSuperAA*ySuperAA);
            colr[1] /= (xSuperAA*ySuperAA);
            colr[2] /= (xSuperAA*ySuperAA);
            myPic.put(i,j, colr);   // done! write it...
        }
    }
}

CRayHit& CScene::trace(CRay &inRay, int depth)
//------------------------------------------------------------------------------
{
	CRayHit result;
	GLdouble xHit,yHit;         // the x,y posiition where ray hits the plane
	GLdouble t0;                // ray length where inRay hits the plane:
	GLdouble xfrac,yfrac;      // fractional part of x/xgap, y/ygap;
	Vec4 tOrig,tDir,normal;             // transformed ray position, direction

	double tHit, numer, denom;
	double tIn = -100000, tOut = 100000;
	int inSurf, outSurf, surface;

	Vec4 dst1;
	double l2oc, l2hc, t, t1, t2, tca;
	bool isL = false;

    // TRANSFROM the ray first:
    

	result.hitItem = -1;
	result.t = -1;
    
	for (int i = 0; i < JT_SHAPES_MAX; i++) {
		if (item[i].exists()) {
			tOrig.mmpy(item[i].worldRay2model,inRay.orig);   // torg == transformed origin
			tDir.mmpy(item[i].worldRay2model,inRay.dir);    // tdir == transformed direction

			switch(item[i].shapeType) {
				case JT_BOX:
					inSurf = -1;
					for (int j = 0; j < 6; j++) {
						switch(j) {
							case 0:
								numer = 1 - tOrig.row[1];
								denom = tDir.row[1];
								break;
							case 1:
								numer = 1 + tOrig.row[1];
								denom = -tDir.row[1];
								break;
							case 2:
								numer = 1 - tOrig.row[0];
								denom = tDir.row[0];
								break;
							case 3:
								numer = 1 + tOrig.row[0];
								denom = -tDir.row[0];
								break;
							case 4:
								numer = 1 - tOrig.row[2];
								denom = tDir.row[2];
								break;
							case 5:
								numer = 1 + tOrig.row[2];
								denom = -tDir.row[2];
								break;
						}
						if (fabs(denom) < 0.00001) {
							if (numer < 0) {
								t = -1;
								break;
							}
						}
						else {
							tHit = numer / denom;
							if (denom > 0) {
								if (tHit < tOut) {
									tOut = tHit;
									outSurf = j;
								}
							}
							else {
								if (tHit > tIn) {
									tIn = tHit;
									inSurf = j;
								}
							}
						}
						if (tIn >= tOut) {
							t = -1;
							break;
						}
					}

					if (tIn < tOut && inSurf != -1) {
						t = tIn;
						switch (inSurf) {
							case 0:
								normal.put(0,1,0,0);
								break;
							case 1:
								normal.put(0,-1,0,0);
								break;
							case 2:
								normal.put(1,0,0,0);
								break;
							case 3:
								normal.put(-1,0,0,0);
								break;
							case 4:
								normal.put(0,0,1,0);
								break;
							case 5:
								normal.put(0,0,-1,0);
								break;
						}
					}
				break;

				case JT_SPHERE:

					dst1.sub(item[i].pos,tOrig);
					l2oc = dst1.dot3(dst1);
					tca = dst1.dot3(tDir) / tDir.dot3(tDir);
					l2hc = (item[i].radius*item[i].radius - l2oc) / tDir.dot3(tDir) + tca*tca;

					if (l2oc >= item[i].radius*item[i].radius) {
						if (tca >= 0) {
							if (l2hc >= 0) {
								t1 = tca - sqrt(l2hc);
								t2 = tca + sqrt(l2hc);
								if (t1 < t2 && t1 >= 0) {
									t = t1;
									normal.put(tOrig.row[0] + tDir.row[0]*t,
											   tOrig.row[1] + tDir.row[1]*t,
											   tOrig.row[2] + tDir.row[2]*t,
											   0);
								}
								else if (t2 >= 0) {
									t = t2;
									normal.put(tOrig.row[0] + tDir.row[0]*t,
											   tOrig.row[1] + tDir.row[1]*t,
											   tOrig.row[2] + tDir.row[2]*t,
											   0);
								}
								else {
									t = -1;
								}
							}
							else {
								t = -1;
							}
						}
						else {
							t = -1;
						}
					}
					else {
						t = tca + sqrt(l2hc);
						normal.put(tOrig.row[0] + tDir.row[0]*t,
								   tOrig.row[1] + tDir.row[1]*t,
								   tOrig.row[2] + tDir.row[2]*t,
								   0);
					}
					break;

				case JT_GRID:
					t0 = -tOrig.row[2] / tDir.row[2];
					if(t0 < 0.0)
					{
						t = -1;
						break;
					}
					xHit = tOrig.row[0] + tDir.row[0] * t0;
					yHit = tOrig.row[1] + tDir.row[1] * t0;
					//Now; did the ray hit a line, or a gap between lines?
					xfrac = xHit - floor(xHit/item[i].xGap);    // get just the fractional part.
					yfrac = yHit - floor(yHit/item[i].yGap);

					t = t0;
					normal.put(0,0,1,0);

					if((xfrac < item[i].lineWidth) || (yfrac < item[i].lineWidth)) {
						isL = true;
					}
					else {
						isL = false;
					}
				break;

				default:
					t = -1;
				break;
			}

			if (t > 0 && (t < result.t || result.t < 0)) {
				result.t = t;
				result.hitItem = i;
				result.isLine = isL;
				tOrig = inRay.orig;
				tDir = inRay.dir;
				 
				result.hitPt.put(tOrig.row[0]+tDir.row[0]*result.t,
								 tOrig.row[1]+tDir.row[1]*result.t,
								 tOrig.row[2]+tDir.row[2]*result.t,
								 1);
				result.normalVec = normal;
				result.viewedFrom.put(-tDir.row[0],-tDir.row[1],-tDir.row[2],0);
			}
		}
	}

	if (result.t == -1) {
		result.colr[0] = bkgndColr[0];
		result.colr[1] = bkgndColr[1];
		result.colr[2] = bkgndColr[2];
	}
	else {
		result = findSurfaceColor(result, depth);
	}

	return result;

}

CRayHit& CScene::findSurfaceColor(CRayHit& eyeHit, int depth) {
	Vec4 orig,light,hwv,normal,dir,refl;
	float lambert, phong;
	float iR = 0,iG = 0,iB = 0;
	CRay shadowFeeler, reflRay;
	CRayHit reflResult;
	int matl;

	for (int i = 0; i < JT_LIGHTS_MAX; i++) {
		if (lamp[i].exists()) {
			if (item[eyeHit.hitItem].shapeType == JT_GRID) {
				if (eyeHit.isLine) {
					iR += lamp[0].I_a.row[0]*matter[1].ambient[0];
					iG += lamp[0].I_a.row[1]*matter[1].ambient[1];
					iB += lamp[0].I_a.row[2]*matter[1].ambient[2];
				}
				else {
					iR += lamp[0].I_a.row[0]*matter[2].ambient[0];
					iG += lamp[0].I_a.row[1]*matter[2].ambient[1];
					iB += lamp[0].I_a.row[2]*matter[2].ambient[2];
				}
			}
			else {
				iR += lamp[0].I_a.row[0]*matter[item[eyeHit.hitItem].matlNum].ambient[0];
				iG += lamp[0].I_a.row[1]*matter[item[eyeHit.hitItem].matlNum].ambient[1];
				iB += lamp[0].I_a.row[2]*matter[item[eyeHit.hitItem].matlNum].ambient[2];
			}

			item[eyeHit.hitItem].worldRay2model.transpose();
			normal.mmpy(item[eyeHit.hitItem].worldRay2model, eyeHit.normalVec);
			normal.row[3] = 0;
			normal.scale(1/sqrt(normal.row[0]*normal.row[0] + normal.row[1]*normal.row[1] + normal.row[2]*normal.row[2]));
			item[eyeHit.hitItem].worldRay2model.transpose();

			light.copy(lamp[i].pos);
			light.mmpy(lamp[i].worldRay2model, light);
			lamp[i].worldRay2model.transpose();
			light.mmpy(lamp[i].worldRay2model, light);
			light.put(-light.row[0],-light.row[1],-light.row[2],1);
			lamp[i].worldRay2model.transpose();

			light.sub(light,eyeHit.hitPt);

			shadowFeeler.orig.copy(eyeHit.viewedFrom);
			shadowFeeler.orig.scale(JT_RAY_EPSILON);
			shadowFeeler.orig.addIn(eyeHit.hitPt);
			shadowFeeler.dir.copy(light);

			if (!isInShadow(shadowFeeler)) {

				light.scale(1/sqrt(light.row[0]*light.row[0] + light.row[1]*light.row[1] + light.row[2]*light.row[2]));

				lambert = light.dot3(normal);
				if (lambert < 0) {
					lambert = 0;
				}

				hwv.add(light,eyeHit.viewedFrom);
				hwv.scale(1/sqrt(hwv.row[0]*hwv.row[0] + hwv.row[1]*hwv.row[1] + hwv.row[2]*hwv.row[2]));

				phong = hwv.dot3(normal);
				if (phong < 0) {
					phong = 0;
				}

				if (item[eyeHit.hitItem].shapeType == JT_GRID) {
					if (eyeHit.isLine) {
						iR += lamp[0].I_d.row[0]*matter[1].diffuse[0]*lambert + lamp[0].I_s.row[0]*matter[1].specular[0]*pow(phong,matter[1].shininess);
						iG += lamp[0].I_d.row[1]*matter[1].diffuse[1]*lambert + lamp[0].I_s.row[1]*matter[1].specular[1]*pow(phong,matter[1].shininess);
						iB += lamp[0].I_d.row[2]*matter[1].diffuse[2]*lambert + lamp[0].I_s.row[2]*matter[1].specular[2]*pow(phong,matter[1].shininess);
					}
					else {
						iR += lamp[0].I_d.row[0]*matter[2].diffuse[0]*lambert + lamp[0].I_s.row[0]*matter[2].specular[0]*pow(phong,matter[2].shininess);
						iG += lamp[0].I_d.row[1]*matter[2].diffuse[1]*lambert + lamp[0].I_s.row[1]*matter[2].specular[1]*pow(phong,matter[2].shininess);
						iB += lamp[0].I_d.row[2]*matter[2].diffuse[2]*lambert + lamp[0].I_s.row[2]*matter[2].specular[2]*pow(phong,matter[2].shininess);
					}
				}
				else {
					iR += lamp[0].I_d.row[0]*matter[item[eyeHit.hitItem].matlNum].diffuse[0]*lambert + lamp[0].I_s.row[0]*matter[item[eyeHit.hitItem].matlNum].specular[0]*pow(phong,matter[item[eyeHit.hitItem].matlNum].shininess);
					iG += lamp[0].I_d.row[1]*matter[item[eyeHit.hitItem].matlNum].diffuse[1]*lambert + lamp[0].I_s.row[1]*matter[item[eyeHit.hitItem].matlNum].specular[1]*pow(phong,matter[item[eyeHit.hitItem].matlNum].shininess);
					iB += lamp[0].I_d.row[2]*matter[item[eyeHit.hitItem].matlNum].diffuse[2]*lambert + lamp[0].I_s.row[2]*matter[item[eyeHit.hitItem].matlNum].specular[2]*pow(phong,matter[item[eyeHit.hitItem].matlNum].shininess);
				}
			}
		}
	}
	eyeHit.colr[0] = iR; eyeHit.colr[1] = iG; eyeHit.colr[2] = iB;

	if (depth == depthMax) {
		return eyeHit;
	}

	if (item[eyeHit.hitItem].shapeType == JT_GRID) {
		if (eyeHit.isLine) {
			matl = 1;
		}
		else {
			matl = 2;
		}
	}
	else {
		matl = item[eyeHit.hitItem].matlNum;
	}
	
	if (matter[matl].reflectivity > 0.0) {
		dir.copy(eyeHit.viewedFrom);
		dir.scale(-1/dir.norm3());
		refl.copy(normal);
		refl.scale(2*dir.dot3(refl));
		refl.sub(dir,refl);

		reflRay.orig.copy(eyeHit.viewedFrom);
		reflRay.orig.scale(JT_RAY_EPSILON);
		reflRay.orig.addIn(eyeHit.hitPt);
		reflRay.dir.copy(refl);

		reflResult = trace(reflRay, depth+1);

		eyeHit.colr[0] += reflResult.colr[0] * matter[item[eyeHit.hitItem].matlNum].reflectivity;
		eyeHit.colr[1] += reflResult.colr[1] * matter[item[eyeHit.hitItem].matlNum].reflectivity;
		eyeHit.colr[2] += reflResult.colr[2] * matter[item[eyeHit.hitItem].matlNum].reflectivity;
	}

	return eyeHit;

}

bool CScene::isInShadow(CRay &inRay)
//------------------------------------------------------------------------------
{
	CRayHit result;
	GLdouble xHit,yHit;         // the x,y posiition where ray hits the plane
	GLdouble t0;                // ray length where inRay hits the plane:
	GLdouble xfrac,yfrac;      // fractional part of x/xgap, y/ygap;
	Vec4 tOrig,tDir,normal;             // transformed ray position, direction

	double tHit, numer, denom;
	double tIn = -100000, tOut = 100000;
	int inSurf, outSurf, surface;

	Vec4 dst1;
	double l2oc, l2hc, t, t1, t2, tca;
	bool isL = false;

    // TRANSFROM the ray first:
    

	result.hitItem = -1;
	result.t = -1;
    
	for (int i = 0; i < JT_SHAPES_MAX; i++) {
		if (item[i].exists()) {
			tOrig.mmpy(item[i].worldRay2model,inRay.orig);   // torg == transformed origin
			tDir.mmpy(item[i].worldRay2model,inRay.dir);    // tdir == transformed direction

			switch(item[i].shapeType) {
				case JT_BOX:
					inSurf = -1;
					for (int j = 0; j < 6; j++) {
						switch(j) {
							case 0:
								numer = 1 - tOrig.row[1];
								denom = tDir.row[1];
								break;
							case 1:
								numer = 1 + tOrig.row[1];
								denom = -tDir.row[1];
								break;
							case 2:
								numer = 1 - tOrig.row[0];
								denom = tDir.row[0];
								break;
							case 3:
								numer = 1 + tOrig.row[0];
								denom = -tDir.row[0];
								break;
							case 4:
								numer = 1 - tOrig.row[2];
								denom = tDir.row[2];
								break;
							case 5:
								numer = 1 + tOrig.row[2];
								denom = -tDir.row[2];
								break;
						}
						if (fabs(denom) < 0.00001) {
							if (numer < 0) {
								t = -1;
								break;
							}
						}
						else {
							tHit = numer / denom;
							if (denom > 0) {
								if (tHit < tOut) {
									tOut = tHit;
									outSurf = j;
								}
							}
							else {
								if (tHit > tIn) {
									tIn = tHit;
									inSurf = j;
								}
							}
						}
						if (tIn >= tOut) {
							t = -1;
							break;
						}
					}

					if (tIn < tOut && inSurf != -1) {
						t = tIn;
					}
				break;

				case JT_SPHERE:

					dst1.sub(item[i].pos,tOrig);
					l2oc = dst1.dot3(dst1);
					tca = dst1.dot3(tDir) / tDir.dot3(tDir);
					l2hc = (item[i].radius*item[i].radius - l2oc) / tDir.dot3(tDir) + tca*tca;

					if (l2oc >= item[i].radius*item[i].radius) {
						if (tca >= 0) {
							if (l2hc >= 0) {
								t1 = tca - sqrt(l2hc);
								t2 = tca + sqrt(l2hc);
								if (t1 < t2 && t1 >= 0) {
									t = t1;
								}
								else if (t2 >= 0) {
									t = t2;
								}
								else {
									t = -1;
								}
							}
							else {
								t = -1;
							}
						}
						else {
							t = -1;
						}
					}
					else {
						t = tca + sqrt(l2hc);
					}
					break;

				case JT_GRID:
					t0 = -tOrig.row[2] / tDir.row[2];
					
					if(t0 < 0.0)
					{
						t = -1;
						break;
					}
					xHit = tOrig.row[0] + tDir.row[0] * t0;
					yHit = tOrig.row[1] + tDir.row[1] * t0;
					
					xfrac = xHit - floor(xHit/item[i].xGap);    // get just the fractional part.
					yfrac = yHit - floor(yHit/item[i].yGap);

					t = t0;
				break;

				default:
					t = -1;
				break;
			}

			if (t > 0 && t < 1) {
				return true;
			}
		}
	}

	return false;

}