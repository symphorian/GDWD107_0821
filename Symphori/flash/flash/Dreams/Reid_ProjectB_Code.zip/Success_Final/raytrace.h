//3456789_123456789_123456789_123456789_123456789_123456789_123456789_123456789_
//
//	Ray-tracing classes.
//
//	01/20/2005 J. Tumblin -- Created.
//  02/22/2007 J. Tumblin -- ported to DevCPP: fixed linker wierdness by adding
//                        conditional compiles (__MY_RAYTRACE) for all .h files
//                     (thanks, Xiang Huang!)
//  02/27/2007 J. Tumblin -- created RayHit,CGeom,CMatl,CScene classes

#if !defined(__MY_RAYTRACE)           // if we haven't already included this file,
#define __MY_RAYTRACE		            // compile it! (#endif at end-of-file).

// multi-platform includes for the GLUT/OpenGL libraries:===================
#if defined(_WIN32)
//this' pragma' hides the Visual Studio 'console window' when the program runs.
//#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#include <windows.h>    // Microsoft Windows functions
#include <GL/GL.h>      // OpenGL 3D graphics rendering functions
#include <GL/Glu.h>     // OpenGL utilties functions
#include "glut.h"       // GLUT functions for windows, keybd, mouse

#elif defined(__APPLE__)
#include <OpenGL/GL.h>  // OpenGL 3D graphics rendering functions
#include <OpenGL/Glu.h> // OpenGL utilties functions
#include <GLUT/glut.h>  // GLUT functions for windows, keybd, mouse

// UNIX, Linux of all flavors;
#else
#include <unistd.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#endif
//=================================================================

#include <math.h>							// for sin(), cos(), tan(), etc.
#include <stdlib.h>							// for all non-core C routines.
#include <stdio.h>							// for printf(), scanf(), etc.

#include <iostream>                         // for cout, cin, etc.
#include <assert.h>							// for error checking by ASSERT().
using namespace std;						// (allow both ANSI & non-ANSI C++)


#include "my_vecmat.h"				    // for home-made vector classes

class CRay
//==============================================================================
// a ray in an unspecified coordinate system (usually 'world' space).
{
public:
	Vec4 orig;					// The starting point of the ray in x,y,z coords.
	Vec4 dir;					// The ray's direction vector.

	bool isShadowRay;

	~CRay(void);				// Default destructor
	 CRay(void);				// Default constructor
};

class CRayHit
//==============================================================================
// All the relevant results we get from 'tracing' a ray into a CScene.
// (a set of CGeom,CMatls,CLights).
{
public:

    double t;                   // ray length parameter: orig + t*dir = hitPt.
    Vec4 viewedFrom;                 // unit-length vector from hitPt back towards
                                // the origin of the ray we traced.
    Vec4 hitPt;                 // 'hit point'-- the world-space location where
    Vec4 normalVec;                            // the ray intersected with the nearest surface.
    int hitItem;                // The CGeom we hit (CScene item[] array index);
                                // use this to get materials properties too.
	bool isLine;

    GLfloat colr[3];            // The final color we computed for this point.
    bool isShadowRay;           // Shadow rays only test for occlusion--they
                                // don't gather the color of what they hit.

//    int depth;                  // recursion depth.

     CRayHit(void);            // default constructor, destructor
    ~CRayHit(void);
//     void init(GLfloat defaultColr[]);// set default color, ray length to -1.
//     void initShadow(void);    // init for shadow ray: color doesn't matter,
                               // ray length = 1, isShadow=true.
};

class CCamera
//==============================================================================
// A perspective camera for ray-tracing, specified in 'world' coordinate system
// by vrp,lookAtPt,vup; iLeft,iRight,iTop,iBot; xmax,ymax.
//
//     Users position and aim the camera by specifying two points and one vector
// in world-space.  The 'view reference point' (vrp) sets camera position; the
// 'lootAt' point sets the cameras' direction-of-gaze, and the 'view up' vector
// (vup) specifies a world-space direction that will appear vertical in the
// camera image.
//     From (vrp,lookAtPt,vup) we compute a (right-handed) camera coord. system
// U,V,N. The coord. system's origin point is 'vrp', and we describe the coord.
// axes by the unit-length world-space vectors U,V,N. To compute these vectors,
// use N = ||vrp-lookAtPt||, U= vup cross N; V= N cross U.  We can easily
// convert a 3D point from camera coords (u,v,n) to world-space coords (x,y,z):
// we start at the camera's origin (vrp), add U,V,N axis vectors weighted by
// the point's u,v,n coords: by the coords (x,y,z) = vrp + U*u + V*v + N*n.
//     Users set the camera's internal parameters by choosing 6 numbers in the
// the camera coordinate system. Here, the 'eye point' or 'center of projection'
// is the origin: (u,v,n)=0,0,0; the camera viewing direction is the -N axis,
// and the U,V axes set the camera image's vertical and horizontal directions
// (x,y). We specify the image in the camera's n=-1 plane; it is the view from
// the origin through the 'image rectangle' with these 4 user-specified corners:
//  	            (iLeft, iTop, -1) (iRight, iTop, -1)
//	                (iLeft, iBot, -1) (iRight, iBot, -1) in  (u,v,n) coords.
// (EXAMPLE: If the user set iLeft=-1, iRight=+1, iTop=+1, iBot = -1, then our
// image rectangle is a square, centered on the -N axis, and our camera's
// field-of-view spans +/- 45 degrees horizontally, +/- 45 degrees vertically.)
//
// Users specify resolution of this image rectangle in pixels (xmax,ymax), and
// the pixels divide the image rectangle into xsize,ysize 'little squares'. Each
// little square has the same width (ufrac) and height (vfrac), where:
//     ufrac = (iRight - iLeft)/xmax;  vfrac = (iTop - iBot)/ymax.
// (note: keep ufrac/vfrac =1, so the image won't appear stretched or squashed).
// The little square at the lower-left corner of the image rectangle holds the
// pixel (0,0), but recall that the pixel is NOT that little square! it is the
// POINT AT THE SQUARE'S CENTER; thus pixel (0,0) location in u,v,n coords is:
//               (iLeft +    0.5*ufrac,  iBot +    0.5*vfrac, -1).
// Similarly, pixel(x,y) location in u,v,n is:
//      uvnPix = (iLeft + (x+0.5)*ufrac, iBot + (y+0.5)*vfrac, -1).
//
// With uvnPix, we can easily make the 'eye' ray in (u,v,n) coords for the (x,y)
// pixel; the ray origin is (0,0,0), and the ray direction vector is
// uvnPix - (0,0,0) = uvnPix. However, we need an eyeRay in world-space coords;
// To convert, replace the ray origin with vrp (already in world-space coords),
// and compure ray direction as a coordinate-weighted sum of the unit-length
// U,V,N axis vectors; eye.dir = uvnPix.u * U + uvnPix.v * V + uvnPix.n * N.
// This 'weighted sum' is just a matrix multiply; cam2world * uvnPix,
// where U,V,N unit-length vectors are the columns of cam2world matrix.
//
// Finally, to move the CCamera in world space, just translate its VRP;
// to rotate CCamera around its VRP, just rotate the u,v,n axes (pre-multiply
// cam2world matrix with a rotation matrix).
{

    // YOU WRITE THE REST.
public:

	GLdouble imgLeft,imgRight,imgBot,imgTop;	// image rectangle's limits in n=-1 plane
	GLdouble zNear;

	int xPixels,yPixels;			        // # of pixels in image rectangle.
	double ufrac,vfrac;             // width, height of 'little squares'.


                                // The ray-tracing camera creates an rectangular
                                // image plane perpendicular to the -Z axis,
                                // spanning 'left' <= x <= 'right' in x,
                                // spanning 'bot' <= y <= 'top' in y.
                                //  It divides this plane into xres x yres
                                // 'little squares' (one for each pixel), and
                                // shoots rays through those squares to find
                                // pixel values.  Without antialiasing, it
                                // shoots ONE ray through the CENTER of each
                                // of the little squares.


	CCamera(void);				// default constructor,
	~CCamera(void);				// default destructor.
    void setFrustum(GLdouble left, GLdouble right,  // set viewing frustum
                    GLdouble bot,  GLdouble top, GLdouble znear,
                    int xsize, int ysize);
    void makeEyeRay(CRay *pEye, GLdouble xpos, GLdouble ypos);
                        // Create a ray from camera origin through the image
                        // plane at (xpos,ypos, znear)
};

class CImageBuf
//===============================================================================
// A floating-point RGB image buffer object to holds ray-traced results for
// display in openGL using the 'glDrawPixels' command.
// easy to display in openGL; easy to use as an openGL texture map too!
{
private:
	GLfloat *pBuffer;

public:
	int xSize,ySize;

	~CImageBuf(void);				// default destructor.
	CImageBuf(void);				// default constructor,
	GLfloat* getBufferPtr(void) {return pBuffer;};

	void resetSize(int newXsize, int newYsize);
									// If buffer is any size except xsize,ysize,
									// then discard its contents and make a
									// new one of the right size.
	void kill(void);				// wipe out the buffer; discard its memory
									// and set size to zero.
	void clear(GLfloat r, GLfloat g, GLfloat b); // fill buffer with one color.
	void put(int x, int y, GLfloat* pRGB);	// Set the pixel at x,y to the
											//RGB=( pRGB[0], pRGB[1], pRGB[2]).
	void put(int x, int y, GLfloat r, GLfloat g, GLfloat b); // put rgb at x,y
    void drawGrid(int xgap, int ygap);
                                    // Draw a grid in the frame buffer;
                                    // spacing in x,y  set by xgap, ygap;/
	void displayMe(int xorig, int yorig);
									// draw buffer with its lower left corner
									// at xorig,yorig.  (2D openGL display)
};

// allowable values for CGeom.shapeType variable.  Add some of your own!
#define JT_SPHERE      0    // A sphere.
#define JT_BOX         1    // An axis-aligned cube.
#define JT_GNDPLANE    2    // An endless 'ground plane' surface.
#define JT_CYLINDER    3    // A cylinder with user-settable radius at each end
                            // and user-settable length.  radius of 0 at either
                            // end makes a cone; length of 0 with nonzero
                            // radius at each end makes a disk.
#define JT_TRIANGLE    4    // a triangle with 3 vertices.
#define JT_BLOBBIES    5    // Implicit surface:Blinn-style Gaussian 'blobbies'.
#define JT_GRID		   6

class CGeom
//==============================================================================
// Generic class for a geometric shape.  Each instance describes just one shape,
// but you can select from several different kinds of shapes by setting
// 'shapeType'.
// CGeom can describe ANY shape, including sphere, box, cone, quadric, etc. and
// holds all/any variables needed for each shapeType.
//
// Advanced Version: try it!
//        Ray tracing lets us position and distort these shapes in a new way;
// instead of transforming the shape itself for 'hit' testing against a traced
// ray, we transform the 3D ray by the matrix 'm_xform' before the hit-test.
// The 'm_xform' matrix simplifies our shape descriptions, because we don't need
// separate parameters for position, orientation, scale, or skew.  For example,
// JT_SPHERE and JT_BOX need NO parameters--they describes a unit sphere or
// unit cube centered at the origin.  To get a larger, rotated, offset sphere
// or box, just set the parameters in m_xform matrix.  Note that you can scale
// the box or sphere differently in different directions, forming ellipsoids for
// the unit sphere and rectangles (or prisms) from the unit box.
{
private:
    bool    isAlive;                    // true/false == use/ignore this shape.

public:
    int     shapeType;                  // JT_SPHERE, JT_BOX, etc.


//BASIC VERSION:
// for JT_SPHERE, JT_BOX,
  	Vec4	pos;		            // World-space position of shape's center
	double	radius;                 // radius for JT_SPHERE, or
                                    // half-width for JT_BOX

    int		matlNum;                    // Index # for material.

    // For line-grid object; a plane at z=zVal that holds a grid of lines
    // aligned with x,y axes:
    double zVal;                        // TEMPORARY! the gridplane's z value
    double xGap,yGap;                   // spacing between lines
    double lineWidth;                   // linewidth as a fraction of xgap,ygap
    Mat4 worldRay2model;                // 4x4 matrix used to transform
                                        // rays from 'world' coord system to
                                        // the coord system for this object.

//-----------Member functions:
	~CGeom(void);			            // default destructor
    CGeom(void);			            // default constructor
    void drawOpenGL(void);              // draw this object in the current
                                        // coordinate system in openGL
//    void applyTransform(CTransRot& src);// Apply the mouse-adjusted translations
                                        // & rotations described in 'src'.
	void createSphere(double r);
	void createCube(void);

    // TRANSFORMATIONS==========================
    // Mimic the openGL API for transforming this object;
    // CAREFUL! these calls modify our worldRay2model matrix (not GL_MODELVIEW)
    //  for use in transforming rays from world coords to model coords.
    //  Accordingly, the construct the INVERSE of the matrix made by their
    //  openGL counterparts, and apply them by POST-multiplying the current
    //  contents of worldRay2model, rather than pre-multiplying as openGL does.
    void rayLoadIdentity(void);
                                // clear current contents; set to I matrix
    void rayTranslate3d(GLdouble tx, GLdouble ty, GLdouble tz);
                                // translate the object's coord sys by tx,ty,tz
    void rayRotate3d(GLdouble deg, GLdouble x, GLdouble y, GLdouble z);
                                // Rotate the object's coord system by deg
                                // degrees around the vector axis (x,y,z)
    void rayScale3d(GLdouble sx, GLdouble sy, GLdouble sz);
                                // Scale the object's coord sx,sy,sz.

	bool exists(void){return isAlive;}; // report the value of isAlive.
	void create(void){isAlive=true;};   // shape exists/doesn't exist.
	void destroy(void){isAlive=false;};
// You do the rest...
};

// Each possible attribute for the CMatl.matlType variable; note we can
// enable any desired combination of these bits if we do a bitwise-OR of each
// desired attribute.  For example, for a phong-lit material with transparency
// and Perlin noise:
//          matlType = 0; // clear all bits
//          matlType = JT_PHONG_BIT | JT_GLASS_BIT | JT_PERLIN;
//  Add some of your own!
// (Assumes 'signed int' has 15 easy-to-set bits).
#define JT_PHONG_BIT       1    // Simple Phong-lit material, like openGL.
#define JT_MIRROR_BIT      2    // mirror-like; recursive ray-tracing lets us
                                // see reflections of other objects in scene.
#define JT_GLASS_BIT       4    // transparency: recursive ray-tracing lets us
                                // see refracted versions of other CGeom shapes
                                // THROUGH this CGeom's shape;
                                // (spheres act as lenses!)
#define JT_3DFUNC_BIT      8    // Use surface hit-point in a 3D function for
                                // 'blend' factor 'b': f(x,y,z)= b; 0 <= b <=1;
                                // use 'b' to find a weighted sum between 2
                                // materials (find indices in 'other[]' array).
#define JT_PERLIN_BIT     16    // Use Perlin Noise to randomly perturn various
                                // materials properties.
#define JT_IMGTEXMAP_BIT  32    // Texture map(s) sets each reflectance value
                                // as a function of two params (t_x, t_y).
#define JT_IMGBUMP_BIT    64    // Texture map(s) modify CGeom's surface
                                // normal directions as function of (t_x,t_y)

#define JT_NDEF8         128           // Not yet defined.
#define JT_NDEF9         256
#define JT_NDEF10        512
#define JT_NDEF11       1024
#define JT_NDEF12       2048
#define JT_NDEF13       4096
#define JT_NDEF14       8192
#define JT_NDEF15      16384

class CMatl
//==============================================================================
// Generic class for a material. Each instance describes just one material, but
// you can select from several different kinds of materials by setting the value
// of 'matlType'. CMatl can describe ANY material, including Phong, glass,
// 3D color functions, proecdural coloring, etc., and holds any/all variables
// needed for each type.
//
//  BASIC:
// Begin with simple Phong-lit materials, defined by  ambient, diffuse, and
// specular reflectance (just like openGL).
//
// ADVANCED VERSIONS:
// Once you have the basic materials working, you can implement exotic materials
// far more easily with ray tracing than you can with openGL.  In particular,
// chrome & glass (clear, colored, frosted) texture maps, environment maps,
// 3D texture functions such as wood, Perlin Noise functions that give you
// nice-looking marble,stucco and even skin-like functions...
{
private:
    bool isAlive;           // true/false to enable/disable this material.

public:
    int matlType;           // material type selector; #define JT_PHONG, etc.
	float ambient[3];
	float diffuse[3];
	float specular[3];
	float shininess;

	float reflectivity;
// YOU DO THE REST.

//-------------------
     CMatl(void);               // default constructor, destructor
    ~CMatl(void);
//	bool exists(void){return isAlive;};    // report the value of isAlive.
//	void create(void){isAlive=true;};      // material exists/doesn't exist.
//	void destroy(void){isAlive=false;};


};

#define JT_POINT_LAMP    0      // point-source light, (Phong lighting)
#define JT_SPOT_LAMP     1      // spot-light with exponential falloff.
#define JT_ENVIR_MAP     2      // Environment Map; any ray that hits no surface
                                // will get color that depends on direction,
                                // taken from a 'box-cube' image. Good for
                                // chrome and glass.  As a start on global
                                // illumination, consider how you might replace
                                // 'ambient' illumination with an average of the
                                // visible parts of the environment map...
#define JT_SHAPED_LAMP   3      // shaped light source; a CGeom object that
                                // emits light in all directions; requires a
                                // set of shadow rays to render properly.
#define JT_TEXTURE_LAMP  4      // emits light whose color varies with direction
                                // according to a texture map image.
class CLight
//==============================================================================
// A generic class for a LIGHT SOURCE. Each instance describes just one light
// source, but you can select from several different kinds by setting the value
// of 'lightType'.  CLight can describe ANY light, including point-light,
// spot-light, area light, shaped-light (e.g. sphere light), etc. and holds
// all/any variables needed for each type.
{
private:
    bool isAlive;              // true/false to enable/disable this light src.

public:
    int lightType;             // light source type selector; #define JT_POINT, etc.
    Vec4 pos;                  // Light position (specifies x,y,z,w; set w=1 for
                               // local lighting, w=0 for light source @ infinity.
// Phong Lighting:
    Vec4 I_a;                  // Ambient illumination color (Phong shading)
    Vec4 I_d;                  // Diffuse illumination color
    Vec4 I_s;                  // Specular illumination color

	Mat4 worldRay2model;

     CLight(void);              // default constructor, destructor.
    ~CLight(void);
	bool exists(void){return isAlive;};   // report the value of isAlive.
	void create(void){isAlive=true;};     // material exists/doesn't exist.
	void destroy(void){isAlive=false;};

	void rayLoadIdentity(void);
                                // clear current contents; set to I matrix
    void rayTranslate3d(GLdouble tx, GLdouble ty, GLdouble tz);
                                // translate the object's coord sys by tx,ty,tz
    void rayRotate3d(GLdouble deg, GLdouble x, GLdouble y, GLdouble z);
                                // Rotate the object's coord system by deg
                                // degrees around the vector axis (x,y,z)
    void rayScale3d(GLdouble sx, GLdouble sy, GLdouble sz);
                                // Scale the object's coord sx,sy,sz.
};

#define JT_SHAPES_MAX     10  //128        // max # of shapes in a CScene object
#define JT_MATLS_MAX      32        // max # of materials in CScene object
#define JT_LIGHTS_MAX      8        // max # of light sources in CScene object.

#define JT_RAY_EPSILON  10E-10      // 'SUBTLE HACK' offset to ray start points
                                    // to push them above or below surfaces.

class CScene
//==============================================================================
// A complete ray tracer class;
//      in my code, one instance (myScene) describes the ray tracer; note
//      that I could easily have multiple ray tracers by just adding more
//      CScene variables.
//The CScene class includes:
// One CCamera object that describes an antialiased ray-tracing camera;
//      in my code, it is the 'rayCam' variable within the CScene class.
//      The CCamera class defines the SOURCE of rays we trace from our eyepoint
//      into the scene, and uses those rays to set output image pixel values.
// a COLLECTION of CGeom objects that each describe an individual visible thing,
//      single item or thing we may see in the scene.
//      in my code, the collection is the 'item[]' array within the CScene class.
//      Each CGeom element in the 'item[]' array may make one shape on-screen;
//      To see three spheres, we'll have 3 CGeom objects, one for each of them.
//      The CGeom class includes a 'matlIndex' index number that selects which
//      material to use in rendering the CGeom shape. I assume all lights in the
//      scene may affect all CGeom shapes, but you may wish to add an light-src
//      index to permit each CGeom object to choose which lights(s) affect it.
// a COLLECTION of CMatl objects that each describe one light-modifying material;
//      in my code, it is the 'matter[]' array within the CScene class.
//      Each CMatl element in the 'matter[]' array describes one particular
//      individual material we will use for one or more CGeom shapes. We may
//      have one CMatl object that describes clear glass, another for a
//      Phong-shaded blue-metal material, another for a texture-map, another
//      for a bump mapped material for the surface of an orange (fruit),
//      another for a marble-like material defined by Perlin noise, etc.
// a COLLECTION of CLight objects that each describe one light source;
//      in my code, the collection is the 'lamp[]' array within the CScene class.
//      Note that I apply all lights to all CGeom objects.  You may wish to
//      add an index to the CGeom class to select which lights affect each item.
//
// The default CScene constructor creates a simple scene that will create a
// picture if traced:
// --rayCam with 45 degree Horiz field of view, aimed at the origin from (0,0,5)
// --item[0] is a unit sphere at the origin that uses matter[0] material;
// --matter[0] material is a shiny red Phong-lit material, lit by lamp[0];
// --lamp[0] is a point-light source at location (5,5,5).
{
public:

    CCamera rayCam;                 // The ray-tracing camera we'll use;
    CRay rayNow;                    // current ray we're tracing.
    CGeom item[JT_SHAPES_MAX];      // array of shapes,  (one or more active)
    CMatl  matter[JT_MATLS_MAX];    // array of materials, (one or more active)
    CLight lamp[JT_LIGHTS_MAX];     // array of light sources. (one or more...)
    GLfloat bkgndColr[3];           // default background color; use this for
                                    // rays that don't hit any scene shapes.
    GLfloat blackColr[3];           // initial value for recursive rays.

    int depthMax;                   // Max. allowed recursion depth for rays.
    bool isAA;                      // isAnti-Aliased. if TRUE, use jittered
                                    // supersampling over 'tiny square' area of
                                    // image, and avg the colors found within.
    int xSuperAA,ySuperAA;          // # of Anti-Alias supersamples per pixel.

    CScene(void);                   // Default constructor
    ~CScene(void);                  // Default destructor

    //===============================================
    void makeRayTracedImage(CImageBuf& myPic, int scanCount);
                                    // Use ray-tracing to render 'scanCount' new
                                    //scanlines of the 'myPic' image.
	CRayHit& trace(CRay& inRay, int depth);

	CRayHit& findSurfaceColor(CRayHit& eyeHit, int depth);
	bool isInShadow(CRay& inRay);
    //===============================================
/*    void trace(CRay& in, CRayHit& hit, int depth);
                                    // Trace the 'in' ray; return the nearest
                                    // surface point hit, its normal, and color
                                    // found by 'depth' recursive calls to trace
                                    // reflections and transparencies.
                                    // (depth=0 results match traceNoRecusion().
    void findSurfaceColor(CRayHit& hit, int depth);
                                    // Given a ray that hits a CGeom item#,
                                    // find the color to return for that ray.
                                    // Use the CGeom's  materials (CMatl), make
                                    // 'shadow' rays to each valid light source,
                                    // compute Phong lighting, and recursively
                                    // trace more rays to determine the color
                                    // caused by reflection and transparency;
                                    // 'depth' sets recursion depth.

    void wipeScene(void);           // delete all shapes,materials,and lights;
                                    // get ready to make an entirely new scene.
    void createMirrorSphereTrio(double rad); // delete all current shapes, and
                                    // make a trio of mirror-like spheres around
                                    // the origin touch and interreflect.

    int createMatl(void);           // find an unused material index;isAlive=true
                                    // return -1 if no more materials available.
    int createShape(void);          // find an unused shape index; isAlive=true
                                    // return -1 if no more shapes available.
    int createLight(void);          // find an unused lamp index; isAlive=true
                                    // return -1 if no more lights available.
    bool destroyMatl(int xmatl);    // At index 'xmatl', set isAlive=false.
                                    // return false if xmatl doesn't exist.
    bool destroyShape(int xshape);  // At index 'xshape', set isAlive=false.
                                    // return false if xshape doesn't exist.
    bool destroyLight(int xlamp);   // At index 'xlamp', set isAlive=false.
                                    // return false if xlamp doesn't exist.
*/
};

#endif // (end of conditional-compile test for __MY_RAYTRACE at start of file.)
