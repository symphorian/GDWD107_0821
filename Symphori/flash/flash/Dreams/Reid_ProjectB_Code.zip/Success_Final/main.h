//==================== All our globally-applied literals========================

#define JT_TITLE	"CS352 RayTrace Starter"// Display window's title bar:
#define JT_WIDTH	512						// initial window half-width,
#define JT_HEIGHT	512						// initial window height in pixels.
#define JT_XPOS		  0						// initial window position
#define JT_YPOS		256
#define JT_ZNEAR	1.0						// near, far clipping planes for
#define JT_ZFAR		5000.0					// the OpenGL 3D camera.


//================= All the local libraries we use or wrote ====================

// multi-platform includes for the GLUT/OpenGL libraries:
#if defined(_WIN32)
//this' pragma' hides the Visual Studio 'console window' when the program runs.
//#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#include <windows.h>    // Microsoft Windows functions
#include <GL/GL.h>      // OpenGL 3D graphics rendering functions
#include <GL/Glu.h>     // OpenGL utilties functions
#include "glut.h"       // GLUT functions for windows, keybd, mouse

#elif defined(__APPLE__)
#include <OpenGL/GL.h>  // OpenGL 3D graphics rendering functions
#include <OpenGL/Glu.h> // OpenGL utilties functions
#include <GLUT/glut.h>  // GLUT functions for windows, keybd, mouse

// UNIX, Linux of all flavors;
#else
#include <unistd.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#endif

//=============================Local

#include "raytrace.h"						// Ray-tracing classes; these use
                                            // (and #include) my_vecmat.h,.cpp.


//================= All built-in libraries we use ==============================

#include <math.h>							// for sin(), cos(), tan(), etc.
#include <stdlib.h>							// for all non-core C routines.
#include <stdio.h>							// for printf(), scanf(), etc.
                       						// for cout, cin, etc.
#include <iostream>                         // For DevCPP (.h won't work!)
//#include <iostream.h>                     // For Visual Studio.
#include <assert.h>							// for error checking by ASSERT().
using namespace std;						// (allow both ANSI & non-ANSI C++)

//=============================================================================
//	C Function Prototypes for all our GLUT and housekeeping:
void printHelp(void);                  // Print out user instructions on-screen.
void init_glut(int *argc, char **argv);	// any/all GLUT initialization
void init_ogl(void);					// any/all OpenGL initialization
void init_raytrace(void);              // any/all RayTracing initialization

					// GLUT callback functions we will register. Called when:
void display(void);						// GLUT says re-draw the display window.
void reshape(int w, int h);				// GLUT says window was re-sized to w,h
void keyboard(unsigned char key, int x, int y);	//GLUT says user pressed a key
void keySpecial(int key, int x, int y);	// GLUT says user pressed a 'special'key
void mouseMove(int xpos,int ypos);		// GLUT says user moved the mouse to..
void mouseClik(int buttonID,int upDown,int xpos, int ypos);
										// GLUT says user click/dragged mouse.
void callMyTracer(void);				// Do a few scanlines of ray-tracing;
										// (called as the GLUT idle task)


//3456789_123456789_123456789_123456789_123456789_123456789_123456789_123456789_
//
//	Mouse- and keyboard-controlled class for rigid-body transforms used in
//	OpenGL/GLUT projects.
//
//	01/06/2005 J. Tumblin -- Created.
//  02/22/2006 J. Tumblin -- ported to DevCPP: fixed linker wierdness by adding
//                        conditional compiles (__MY_RAYTRACE) for all .h files
//                     (thanks, Xiang Huang!)class CTransRot

class CTransRot
//==============================================================================
// Record / accumulate offset amounts and rotation amounts from mouse & keyboard
{
public:
int m_x,m_y;					// last mouse-dragging position we examined.

double	pos[3];					// cumulative position offset
double	rot[3];					// cumulative rotation about x,y, and z axes
int		isDragging;				// TRUE if user is holding down the mouse button
								// that affects our value(s); else FALSE.


~CTransRot(void);				// default destructor
 CTransRot(void);				// default constructor
void reset(void);				// reset everything to zero.
void rotDragTo(int xNew, int yNew);	// Find rotations from mouse dragging.
void transDragTo(int xNew, int yNew); // Find translations from mouse dragging.
void applyMatrix(void);	        // apply translations, rotations to openGL.
void applyRayMatrix(CGeom& dest);// apply same transforms to ray-traced object.
void applyRayMatrix(CLight& dest);
void drawAxes(int colr);        // Draw 3D axes in the current coordinate system
                                // colr=0 for x=red,    y=green     z=blue,
                                // colr=1 for x=yellow, y=cyan      z=magenta
                                // colr=2 for x=white   y=white     z=green
};
