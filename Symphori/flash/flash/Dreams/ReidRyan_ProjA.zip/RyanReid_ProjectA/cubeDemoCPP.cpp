#include "cubeDemoCPP.h"
using namespace std;

#define F_NONE              0
#define F_GRAVITY_AXIS      1
#define F_GRAVITY_OMNI      2
#define F_GRAVITY_PARTICLE  3
#define F_ROTATION_FIELD    4
#define F_SPRING            5
#define F_DAMPER            6
#define F_MAX               7

#define C_NONE          0
#define C_AXIS          1
#define C_VELOCITY      2
#define C_RESET         3
#define C_MAX           4

static int nu_display_width = 640;
static int nu_display_height = 640;
static int nu_display_xpos = 200;
static int nu_display_ypos = 100;
static int nu_Anim_isOn = 1;

GLdouble xclik=0, yclik=0;
GLdouble xtheta=0, ytheta=0;
GLdouble xcam=0, ycam=0;
GLdouble xmov=0,ymov=0,zmov=-20;
GLboolean showHelp=false, leftDown=false, rightDown = false;

bool backwindSolve = true;

double gx=0, gy=0, gz=0;

// Particle class - contains particle info like current position,
// initial position (used for reset), previous positions (used
// for trails), color, mass, and their derivatives.
// And don't forget about force.

class Particle {

    public:
        boolean moveable;

        double x;
        double y;
        double z;

        double *xMem;
        double *yMem;
        double *zMem;

        int memCount;
        int memIndex;

        double xInit;
        double yInit;
        double zInit;

        double xVel;
        double yVel;
        double zVel;

        double xForce;
        double yForce;
        double zForce;

        float r;
        float g;
        float b;
        float a;

        float rDot;
        float gDot;
        float bDot;
        float aDot;

        double mass;
        double massDot;

        int age;

        int size;


        Particle() {           // Default constructor
            moveable = true;

            xInit = 0;
            yInit = 0;
            zInit = 0;

            x = 0;
            y = 0;
            z = 0;

            memCount = 0;
            memIndex = 0;

            xVel = 0;
            yVel = 0;
            zVel = 0;

            xForce = 0;
            yForce = 0;
            zForce = 0;

            r = 0.5;
            g = 0.5;
            b = 0.5;
            a = 1.0;

            rDot = 0;
            gDot = 0;
            bDot = 0;
            aDot = 0;

            mass = 1;
            massDot = 0;

            age = 0;

            size = 2;
        }

        void setMem(int numOfMem) {    // Initializes the position memory arrays
            memCount = numOfMem;
            xMem = new double[numOfMem];
            yMem = new double[numOfMem];
            zMem = new double[numOfMem];
        }

        void setPosition(double newX, double newY, double newZ) {
            xInit = newX;        // Sets position
            yInit = newY;
            zInit = newZ;
            x = newX;
            y = newY;
            z = newZ;
        }

        void setColor(float initR, float initG, float initB, float initA) {
            r = initR;           // Sets color
            g = initG;
            b = initB;
            a = initA;
        }

        void setColorDeriv(float rDer, float gDer, float bDer, float aDer) {
            rDot = rDer;         // Sets color derivative
            gDot = gDer;
            bDot = bDer;
            aDot = aDer;
        }

        void setMassDeriv(double massDer) {  // Sets mass derivative
            massDot = massDer;
        }

        void setAge(int initAge) {          // Sets age
            age = initAge;
        }

        void draw() {       // Draw function: if memCount != 0, it draws memCount previous states
                            //                else just draw the current position
            if (memCount != 0){
                xMem[memIndex] = x;
                yMem[memIndex] = y;
                zMem[memIndex] = z;

                int tempIndex = memIndex;

                for (int i = 0; i < memCount; i++) {
                    if (xMem[tempIndex] != 0 && yMem[tempIndex] != 0 && zMem[tempIndex] != 0) {
                        glPushMatrix();

                        glColor4f(r, g, b, a);

                        glPointSize(size);

                        glBegin(GL_POINTS);
                        glVertex3d(xMem[tempIndex],yMem[tempIndex],zMem[tempIndex]);
                        glEnd();

                        glPopMatrix();
                    }

                    if (tempIndex == 0) {
                        tempIndex = memCount - 1;
                    }
                    else {
                        tempIndex--;
                    }
                }

                if (memIndex == memCount - 1) {
                    memIndex = 0;
                }
                else {
                    memIndex++;
                }
            }
            else {
                glPushMatrix();

                glColor4f(r, g, b, a);

                glPointSize(size);

                glBegin(GL_POINTS);
                glVertex3d(x,y,z);
                glEnd();

                glPopMatrix();
            }
        }
};


// Force Class - Contains variables for various forces
// like axis, cyclinder, rotation, spring, and damper forces

class Force {


    public:
        int forceType;

        double x;
        double y;
        double z;
        double xStrength;
        double yStrength;
        double zStrength;
        double xAxisScale;
        double yAxisScale;
        double zAxisScale;

        double limit;

        double damper_c;

        double spring_k;
        double spring_restLength;
        int end1, end2;

        Force() {     // Default constructor

            forceType = F_GRAVITY_AXIS;

            x = 0;
            y = 0;
            z = 0;
            xStrength = 0;
            yStrength = 0.0001;
            zStrength = 0;
            xAxisScale = 0;
            yAxisScale = 1;
            zAxisScale = 0;

            limit = 0;

            damper_c = 0;

            spring_k = 0;
            spring_restLength = 0;

            end1 = 0;
            end2 = 0;
        }

        void draw(Particle p1, Particle p2) {

            switch (forceType) {
//                case F_GRAVITY_OMNI:    // draws the point exerting a force on
//                glPushMatrix();         // all particles
//
//                glColor3d(.9, .1, .1);
//
//                glPointSize(10);
//
//                glBegin(GL_POINTS);
//                glVertex3d(x,y,z);
//                glEnd();
//
//                glPopMatrix();
//                break;

                case F_GRAVITY_PARTICLE:  // draws the force attached to a particle
                glPushMatrix();           // red if attractive force, blue if repulsive

                if (xStrength < 0 && yStrength < 0 && zStrength < 0) {
                    glColor3d(.1, .1, .9);
                }
                else {
                    glColor3d(.9, .1, .1);
                }

                glPointSize(5);

                glBegin(GL_POINTS);
                glVertex3d(p1.x,p1.y,p1.z);
                glEnd();

                glPopMatrix();
                break;

                case F_SPRING:
                glPushMatrix();

                glColor3d(.9,.1,.1);

                glBegin(GL_LINES);
                glVertex3d(p1.x, p1.y, p1.z);
                glVertex3d(p2.x, p2.y, p2.z);
                glEnd();

                glPopMatrix();
                break;

                default:
                break;
            }
        }

};

// Constraint class - contains variables for box constraints and resets

class Constraint {

    public:
        int constraintType;

        double xmin, xmax, ymin, ymax, zmin, zmax;
        double xNorm, yNorm, zNorm;
        float rReset, bReset, gReset, aReset;
        double massReset;
        double ageLimit;
        double maxVel;
        double bounceLoss;

        Constraint() {     // default constructor

            constraintType = C_AXIS;

            xmin = -2;
            xmax = 2;
            ymin = -2;
            ymax = 2;
            zmin = -2;
            zmax = 2;

            xNorm = 0;
            yNorm = 0;
            zNorm = 0;

            rReset = 0.5;
            gReset = 0.5;
            bReset = 0.5;
            aReset = 1.0;

            massReset = 1;

            ageLimit = 0;

            maxVel = 0;

            bounceLoss = 0.70;
        }

        void draw() {      // draws the lines defining the box constraint

            switch (constraintType) {
                case C_AXIS:
                glPushMatrix();

                glColor3f(1,1,1);

                glBegin(GL_LINE_LOOP);
                glVertex3d(xmin,ymin,zmin);
                glVertex3d(xmin,ymin,zmax);
                glVertex3d(xmin,ymax,zmax);
                glVertex3d(xmin,ymax,zmin);
                glEnd();

                glBegin(GL_LINE_LOOP);
                glVertex3d(xmax,ymin,zmin);
                glVertex3d(xmax,ymin,zmax);
                glVertex3d(xmax,ymax,zmax);
                glVertex3d(xmax,ymax,zmin);
                glEnd();

                glBegin(GL_LINES);
                glVertex3d(xmin,ymin,zmin);
                glVertex3d(xmax,ymin,zmin);
                glVertex3d(xmin,ymin,zmax);
                glVertex3d(xmax,ymin,zmax);
                glVertex3d(xmin,ymax,zmin);
                glVertex3d(xmax,ymax,zmin);
                glVertex3d(xmin,ymax,zmax);
                glVertex3d(xmax,ymax,zmax);
                glEnd();

                glPopMatrix();
                break;

                default:
                break;
            }
        }

};

// Particles Class - contains the state arrays of Particle objectss, arrays of Force objects,
// and Constraint objects; in addition, there are SEVERAL helper functions for adding new
// Particle, Force, and Constraint objects in useful preset ways.  There are also the basic
// update functions (applyAllForces, findDot, render, solve, and constrain).

class Particles {

    public:

        double x;
        double y;
        double z;

        int particleCount;

        Particle *s0;
        Particle *sDot;
        Particle *sM;
        Particle *s1;

        int forceCount;

        Force *f0;

        int constraintCount;

        Constraint *c0;

        Particles(int pCount, int fCount, int cCount) {   // default constructor
            particleCount = pCount;
            forceCount = fCount;
            constraintCount = cCount;


            s0 = new Particle[pCount];
            sDot = new Particle[pCount];
            sM = new Particle[pCount];
            s1 = new Particle[pCount];

            f0 = new Force[fCount];

            c0 = new Constraint[cCount];
        }

        // Adds a new particle to the s0, sDot, sM, and s1
        void addParticle(double initX, double initY, double initZ, double ms, int memNum) {
            particleCount++;

            int i;
            Particle *temp;

            temp = s0;
            s0 = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                s0[i] = temp[i];
            }
            s0[particleCount - 1].setMem(memNum);
            s0[particleCount - 1].setPosition(initX, initY, initZ);
            s0[particleCount - 1].mass = ms;
            delete [] temp;

            temp = sDot;
            sDot = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                sDot[i] = temp[i];
            }
            delete [] temp;

            temp = sM;
            sM = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                sM[i] = temp[i];
            }
            delete [] temp;

            temp = s1;
            s1 = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                s1[i] = temp[i];
            }
            s1[particleCount - 1].setMem(memNum);
            s1[particleCount - 1].setPosition(initX,initY,initZ);
            s1[particleCount - 1].mass = ms;
            delete [] temp;
        }

        // Adds a new particle that does not move
        void addImmovableParticle(double initX, double initY, double initZ) {
            particleCount++;

            int i;
            Particle *temp;

            temp = s0;
            s0 = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                s0[i] = temp[i];
            }
            s0[particleCount - 1].setPosition(initX, initY, initZ);
            s0[particleCount - 1].moveable = false;
            delete [] temp;

            temp = sDot;
            sDot = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                sDot[i] = temp[i];
            }
            sDot[particleCount - 1].moveable = false;
            delete [] temp;

            temp = sM;
            sM = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                sM[i] = temp[i];
            }
            sM[particleCount - 1].moveable = false;
            delete [] temp;

            temp = s1;
            s1 = new Particle[particleCount];
            for (i = 0; i < particleCount - 1; i++) {
                s1[i] = temp[i];
            }
            s1[particleCount - 1].moveable = false;
            delete [] temp;
        }

        // Adds a gravity force, that always applies gForce to the yAxis
        void addGravityForce(double gForce) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_GRAVITY_AXIS;

            f0[forceCount - 1].xStrength = gForce;
            f0[forceCount - 1].yStrength = gForce;
            f0[forceCount - 1].zStrength = gForce;

            f0[forceCount - 1].yAxisScale = 1;

            delete [] temp;
        }

        // Adds a planet force (ie a force that originates from a single point
        // and affects all particles in the system
        void addPlanetForce(double gForce, double xPos, double yPos, double zPos) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_GRAVITY_OMNI;

            f0[forceCount - 1].x = xPos;
            f0[forceCount - 1].y = yPos;
            f0[forceCount - 1].z = zPos;
            f0[forceCount - 1].xStrength = gForce;
            f0[forceCount - 1].yStrength = gForce;
            f0[forceCount - 1].zStrength = gForce;
            f0[forceCount - 1].xAxisScale = 1;
            f0[forceCount - 1].yAxisScale = 1;
            f0[forceCount - 1].zAxisScale = 1;

            delete [] temp;
        }

        // adds a force that attaches to a particle and affects all
        // other particles in the system
        void addParticleForce(double gForce, int pIndex, double lmt) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_GRAVITY_PARTICLE;

            f0[forceCount - 1].xStrength = gForce;
            f0[forceCount - 1].yStrength = gForce;
            f0[forceCount - 1].zStrength = gForce;

            f0[forceCount - 1].limit = lmt;

            f0[forceCount - 1].end1 = pIndex;

            delete [] temp;
        }

        // adds a force to 1 to 3 axes (function named because it was initially used to apply to 2 axes,
        // thus creating a 'cylindrical' force field
        void addCylinderForce(double gForce, double xPos, double yPos, double zPos, double xScale, double yScale, double zScale) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_GRAVITY_OMNI;

            f0[forceCount - 1].x = xPos;
            f0[forceCount - 1].y = yPos;
            f0[forceCount - 1].z = zPos;
            f0[forceCount - 1].xStrength = gForce;
            f0[forceCount - 1].yStrength = gForce;
            f0[forceCount - 1].zStrength = gForce;
            f0[forceCount - 1].xAxisScale = xScale;
            f0[forceCount - 1].yAxisScale = yScale;
            f0[forceCount - 1].zAxisScale = zScale;

            delete [] temp;
        }

        // adds a force to 1 to 3 axes with optional limits. the strength of force direction is also
        // determined in the function
        void addAxisForce(double lmt, double xPos, double yPos, double zPos, double xScale, double yScale, double zScale, double xS, double yS, double zS) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_GRAVITY_OMNI;

            f0[forceCount - 1].x = xPos;
            f0[forceCount - 1].y = yPos;
            f0[forceCount - 1].z = zPos;
            f0[forceCount - 1].xStrength = xS;
            f0[forceCount - 1].yStrength = yS;
            f0[forceCount - 1].zStrength = zS;
            f0[forceCount - 1].xAxisScale = xScale;
            f0[forceCount - 1].yAxisScale = yScale;
            f0[forceCount - 1].zAxisScale = zScale;
            f0[forceCount - 1].limit = lmt;

            delete [] temp;
        }

        // applies a rotation force to the specified axes
        void addRotationForce(double lmt, double gForce, double xPos, double yPos, double zPos, double xScale, double yScale, double zScale) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_ROTATION_FIELD;

            f0[forceCount - 1].x = xPos;
            f0[forceCount - 1].y = yPos;
            f0[forceCount - 1].z = zPos;
            f0[forceCount - 1].xStrength = gForce;
            f0[forceCount - 1].yStrength = gForce;
            f0[forceCount - 1].zStrength = gForce;
            f0[forceCount - 1].xAxisScale = xScale;
            f0[forceCount - 1].yAxisScale = yScale;
            f0[forceCount - 1].zAxisScale = zScale;
            f0[forceCount - 1].limit = lmt;

            delete [] temp;
        }

        // adds a spring force between two particles
        void addSpringForce(double k, double restLength, int p1, int p2) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_SPRING;

            f0[forceCount - 1].spring_k = k;
            f0[forceCount - 1].spring_restLength = restLength;

            f0[forceCount - 1].end1 = p1;
            f0[forceCount - 1].end2 = p2;

            delete [] temp;
        }

        // adds a damper force between two particles
        void addDamperForce(double c, int p1, int p2) {
            forceCount++;

            Force *temp;

            temp = f0;
            f0 = new Force[forceCount];
            for (int i = 0; i < forceCount - 1; i++) {
                f0[i] = temp[i];
            }

            f0[forceCount - 1].forceType = F_DAMPER;

            f0[forceCount - 1].damper_c = c;

            f0[forceCount - 1].end1 = p1;
            f0[forceCount - 1].end2 = p2;

            delete [] temp;
        }

        // adds a box constraint to the system
        void addBoxConstraint(double initxmin, double initxmax, double initymin, double initymax, double initzmin, double initzmax, double loss) {
            constraintCount++;

            Constraint *temp;

            temp = c0;
            c0 = new Constraint[constraintCount];
            for (int i = 0; i < constraintCount - 1; i++) {
                c0[i] = temp[i];
            }

            c0[constraintCount - 1].constraintType = C_AXIS;

            c0[constraintCount - 1].xmin = initxmin;
            c0[constraintCount - 1].xmax = initxmax;
            c0[constraintCount - 1].ymin = initymin;
            c0[constraintCount - 1].ymax = initymax;
            c0[constraintCount - 1].zmin = initzmin;
            c0[constraintCount - 1].zmax = initzmax;

            c0[constraintCount - 1].bounceLoss = loss;

            delete [] temp;
        }

        // adds a constraint that resets particles' positions
        void addResetPosConstraint(double ageLmt) {
            constraintCount++;

            Constraint *temp;

            temp = c0;
            c0 = new Constraint[constraintCount];
            for (int i = 0; i < constraintCount - 1; i++) {
                c0[i] = temp[i];
            }

            c0[constraintCount - 1].constraintType = C_RESET;

            c0[constraintCount - 1].ageLimit = ageLmt;

            delete [] temp;
        }

        // adds a constraint that resets particles' colors
        void addResetColorConstraint(float rstR, float rstG, float rstB, float rstA, double ageLmt) {
            constraintCount++;

            Constraint *temp;

            temp = c0;
            c0 = new Constraint[constraintCount];
            for (int i = 0; i < constraintCount - 1; i++) {
                c0[i] = temp[i];
            }

            c0[constraintCount - 1].constraintType = C_RESET;

            c0[constraintCount - 1].rReset = rstR;
            c0[constraintCount - 1].gReset = rstG;
            c0[constraintCount - 1].bReset = rstB;
            c0[constraintCount - 1].aReset = rstA;

            c0[constraintCount - 1].ageLimit = ageLmt;

            delete [] temp;
        }
        // adds a constraint to reset particles' mass
        void addResetMassConstraint(double rstMass, double ageLmt) {
            constraintCount++;

            Constraint *temp;

            temp = c0;
            c0 = new Constraint[constraintCount];
            for (int i = 0; i < constraintCount - 1; i++) {
                c0[i] = temp[i];
            }

            c0[constraintCount - 1].constraintType = C_RESET;

            c0[constraintCount - 1].massReset = rstMass;

            c0[constraintCount - 1].ageLimit = ageLmt;

            delete [] temp;
        }

        // adds a constraint to reset particles' position, color, and mass
        void addResetAllConstraint(float rstR, float rstG, float rstB, float rstA, double rstMass, double ageLmt) {
            constraintCount++;

            Constraint *temp;

            temp = c0;
            c0 = new Constraint[constraintCount];
            for (int i = 0; i < constraintCount - 1; i++) {
                c0[i] = temp[i];
            }

            c0[constraintCount - 1].constraintType = C_RESET;

            c0[constraintCount - 1].rReset = rstR;
            c0[constraintCount - 1].gReset = rstG;
            c0[constraintCount - 1].bReset = rstB;
            c0[constraintCount - 1].aReset = rstA;

            c0[constraintCount - 1].massReset = rstMass;

            c0[constraintCount - 1].ageLimit = ageLmt;

            delete [] temp;
        }

        // sets a limit to particles velocity (undeveloped)
        void addVelConstraint(double maxSpd) {
            constraintCount++;

            Constraint *temp;

            temp = c0;
            c0 = new Constraint[constraintCount];
            for (int i = 0; i < constraintCount - 1; i++) {
                c0[i] = temp[i];
            }

            c0[constraintCount - 1].constraintType = C_VELOCITY;

            c0[constraintCount - 1].maxVel = maxSpd;

            delete [] temp;
        }

        // applies the forces to all applicable particles
        void applyAllForces() {


            int i;

            for (i = 0; i < particleCount; i++) {
                s0[i].xForce = 0;
                s0[i].yForce = 0;
                s0[i].zForce = 0;
            }

            for (i = 0; i < forceCount; i++) {
                int j;
                double mag, length;
                switch (f0[i].forceType) {
                    case F_NONE:
                    break;

                    case F_GRAVITY_AXIS:
                    for (j = 0; j < particleCount; j++) {
                        if (s0[j].moveable) {
                            s0[j].zForce += f0[i].xStrength * f0[i].xAxisScale;
                            s0[j].yForce += f0[i].yStrength * f0[i].yAxisScale;
                            s0[j].zForce += f0[i].zStrength * f0[i].zAxisScale;
                        }
                    }
                    break;

                    case F_GRAVITY_OMNI:
                    for (j = 0; j < particleCount; j++) {
                        if (s0[j].moveable) {
                            mag = sqrt(pow(f0[i].x - s0[j].x,2) * f0[i].xAxisScale + pow(f0[i].y - s0[j].y,2) * f0[i].yAxisScale + pow(f0[i].z - s0[j].z,2) * f0[i].zAxisScale);
                            length = sqrt(pow(f0[i].x - s0[j].x,2) + pow(f0[i].y - s0[j].y,2) + pow(f0[i].z - s0[j].z,2));
                            if (f0[i].limit == 0) {
                                s0[j].xForce += f0[i].xAxisScale * f0[i].xStrength * (f0[i].x - s0[j].x) / mag;
                                s0[j].yForce += f0[i].yAxisScale * f0[i].yStrength * (f0[i].y - s0[j].y) / mag;
                                s0[j].zForce += f0[i].zAxisScale * f0[i].zStrength * (f0[i].z - s0[j].z) / mag;
                            }
                            else if (mag < f0[i].limit){
                                s0[j].xForce += f0[i].xStrength * ((f0[i].limit - mag) / f0[i].limit);
                                s0[j].yForce += f0[i].yStrength * ((f0[i].limit - mag) / f0[i].limit);
                                s0[j].zForce += f0[i].zStrength * ((f0[i].limit - mag) / f0[i].limit);
                            }
                        }
                    }
                    break;

                    case F_GRAVITY_PARTICLE:
                    for (j = 0; j < particleCount; j++) {
                        if (s0[j].moveable) {
                            if (j != f0[i].end1) {
                                mag = sqrt(pow(s0[f0[i].end1].x - s0[j].x,2) + pow(s0[f0[i].end1].y - s0[j].y,2) + pow(s0[f0[i].end1].z - s0[j].z,2));
                                if (f0[i].limit == 0 || mag < f0[i].limit) {
                                    s0[j].xForce += f0[i].xStrength * (s0[f0[i].end1].x - s0[j].x) / mag;
                                    s0[j].yForce += f0[i].yStrength * (s0[f0[i].end1].y - s0[j].y) / mag;
                                    s0[j].zForce += f0[i].zStrength * (s0[f0[i].end1].z - s0[j].z) / mag;
                                }
                            }
                        }
                    }
                    break;

                    case F_ROTATION_FIELD:
                    for (j = 0; j < particleCount; j++) {
                        if (s0[j].moveable) {
                            if (f0[i].xAxisScale != 0) {
                                mag = sqrt(pow(f0[i].y - s0[j].y,2) + pow(f0[i].z - s0[j].z,2));
                                length = sqrt(pow(f0[i].x - s0[j].x,2) + pow(f0[i].y - s0[j].y,2) + pow(f0[i].z - s0[j].z,2));
                                if (f0[i].limit == 0) {
                                    //s0[j].xForce += f0[i].xStrength * (f0[i].x - s0[j].x) / mag;
                                    s0[j].yForce += -f0[i].yStrength * (f0[i].z - s0[j].z) / mag;
                                    s0[j].zForce += f0[i].zStrength * (f0[i].y - s0[j].y) / mag;
                                }
                                else if (mag < f0[i].limit){
                                    //s0[j].xForce += f0[i].xStrength * (f0[i].x - s0[j].x) / length * ((f0[i].limit - mag) / f0[i].limit);
                                    s0[j].yForce += -f0[i].yStrength * (f0[i].z - s0[j].z) / length * ((f0[i].limit - mag) / f0[i].limit);
                                    s0[j].zForce += f0[i].zStrength * (f0[i].y - s0[j].y) / length * ((f0[i].limit - mag) / f0[i].limit);
                                }
                            }
                            if (f0[i].yAxisScale != 0) {
                                mag = sqrt(pow(f0[i].x - s0[j].x,2) + pow(f0[i].z - s0[j].z,2));
                                length = sqrt(pow(f0[i].x - s0[j].x,2) + pow(f0[i].y - s0[j].y,2) + pow(f0[i].z - s0[j].z,2));
                                if (f0[i].limit == 0) {
                                    s0[j].xForce += f0[i].xStrength * (f0[i].z - s0[j].z) / mag;
                                    //s0[j].yForce += f0[i].yStrength * (f0[i].y - s0[j].y) / mag;
                                    s0[j].zForce += -f0[i].zStrength * (f0[i].x - s0[j].x) / mag;
                                }
                                else if (mag < f0[i].limit){
                                    s0[j].xForce += f0[i].xStrength * (f0[i].z - s0[j].z) / length * ((f0[i].limit - mag) / f0[i].limit);
                                    //s0[j].yForce += -f0[i].yStrength * (f0[i].y - s0[j].y) / length * ((f0[i].limit - mag) / f0[i].limit);
                                    s0[j].zForce += -f0[i].zStrength * (f0[i].x - s0[j].x) / length * ((f0[i].limit - mag) / f0[i].limit);
                                }
                            }
                        }
                    }
                    break;

                    case F_SPRING:
                    double xDiff = s0[f0[i].end2].x - s0[f0[i].end1].x;
                    double yDiff = s0[f0[i].end2].y - s0[f0[i].end1].y;
                    double zDiff = s0[f0[i].end2].z - s0[f0[i].end1].z;

                    mag = sqrt(pow(xDiff,2) + pow(yDiff,2) + pow(zDiff,2));
                    double disp = mag - f0[i].spring_restLength;

                    double f = f0[i].spring_k * disp;

                    if (s0[f0[i].end2].moveable) {
                        s0[f0[i].end2].xForce += -f * (xDiff / mag);
                        s0[f0[i].end2].yForce += -f * (yDiff / mag);
                        s0[f0[i].end2].zForce += -f * (zDiff / mag);
                    }
                    if (s0[f0[i].end1].moveable) {
                        s0[f0[i].end1].xForce += f * (xDiff / mag);
                        s0[f0[i].end1].yForce += f * (yDiff / mag);
                        s0[f0[i].end1].zForce += f * (zDiff / mag);
                    }
                    break;

                    case F_DAMPER:
                    if (s0[f0[i].end1].moveable) {
                        s0[f0[i].end1].xForce += -f0[i].damper_c * s0[f0[i].end1].xVel;
                        s0[f0[i].end1].yForce += -f0[i].damper_c * s0[f0[i].end1].yVel;
                        s0[f0[i].end1].zForce += -f0[i].damper_c * s0[f0[i].end1].zVel;
                    }
                    if (s0[f0[i].end2].moveable) {
                        s0[f0[i].end2].xForce += -f0[i].damper_c * s0[f0[i].end2].xVel;
                        s0[f0[i].end2].yForce += -f0[i].damper_c * s0[f0[i].end2].yVel;
                        s0[f0[i].end2].zForce += -f0[i].damper_c * s0[f0[i].end2].zVel;
                    }
                    break;

                    default:
                    break;
                }
            }
        }

        // finds the state derivative and stores it in stateDot
        void findDot(Particle *state, Particle *stateDot) {
            int i;

            for (i = 0; i < particleCount; i++) {
                stateDot[i].x = state[i].xVel;
                stateDot[i].y = state[i].yVel;
                stateDot[i].z = state[i].zVel;

                stateDot[i].xVel = state[i].xForce / s0[i].mass;
                stateDot[i].yVel = state[i].yForce / s0[i].mass;
                stateDot[i].zVel = state[i].zForce / s0[i].mass;

                stateDot[i].xForce = 0;  // (d/dt) force
                stateDot[i].yForce = 0;  // temporarily set to 0
                stateDot[i].zForce = 0;

                stateDot[i].r = state[i].rDot;   // (d/dt) colors
                stateDot[i].g = state[i].gDot;   // also temporarily set to 0
                stateDot[i].b = state[i].bDot;
                stateDot[i].a = state[i].aDot;

                stateDot[i].mass = state[i].massDot; // (d/dt) mass
                stateDot[i].massDot = 0;

                stateDot[i].age = 1;  // (d/dt) age
            }
        }

        // draws all particles, forces, and constraints
        void render() {
            int i;

            for (i = 0; i < particleCount; i++) {
                s0[i].draw();
            }

            for (i = 0; i < forceCount; i++) {
                f0[i].draw(s0[f0[i].end1], s0[f0[i].end2]);
            }

            for (i = 0; i < constraintCount; i++) {
                c0[i].draw();
            }
        }

        // applies derivatives to states
        void solve() {
            findDot(s0, sDot);

            int i;
            for (i = 0; i < particleCount; i++) {
                sM[i].x = s0[i].x + .5 * sDot[i].x;
                sM[i].y = s0[i].y + .5 * sDot[i].y;
                sM[i].z = s0[i].z + .5 * sDot[i].z;

                sM[i].xVel = s0[i].xVel + .5 * sDot[i].xVel;
                sM[i].yVel = s0[i].yVel + .5 * sDot[i].yVel;
                sM[i].zVel = s0[i].zVel + .5 * sDot[i].zVel;

                sM[i].xForce = s0[i].xForce + .5 * sDot[i].xForce;
                sM[i].yForce = s0[i].yForce + .5 * sDot[i].yForce;
                sM[i].zForce = s0[i].zForce + .5 * sDot[i].zForce;

                sM[i].r = s0[i].r + .5 * sDot[i].r;
                sM[i].g = s0[i].g + .5 * sDot[i].g;
                sM[i].b = s0[i].b + .5 * sDot[i].b;
                sM[i].a = s0[i].a + .5 * sDot[i].a;

                sM[i].mass = s0[i].mass + .5 * sDot[i].mass;
                sM[i].age = s0[i].age + .5 * sDot[i].age;
            }

            findDot(sM,sDot);

            for (i = 0; i < particleCount; i++) {
                s1[i].x = s0[i].x + sDot[i].x;
                s1[i].y = s0[i].y + sDot[i].y;
                s1[i].z = s0[i].z + sDot[i].z;

                s1[i].xVel = s0[i].xVel + sDot[i].xVel;
                s1[i].yVel = s0[i].yVel + sDot[i].yVel;
                s1[i].zVel = s0[i].zVel + sDot[i].zVel;

                s1[i].xForce = s0[i].xForce + sDot[i].xForce;
                s1[i].yForce = s0[i].yForce + sDot[i].yForce;
                s1[i].zForce = s0[i].zForce + sDot[i].zForce;

                s1[i].r = s0[i].r + sDot[i].r;
                s1[i].g = s0[i].g + sDot[i].g;
                s1[i].b = s0[i].b + sDot[i].b;
                s1[i].a = s0[i].a + sDot[i].a;

                s1[i].mass = s0[i].mass + sDot[i].mass;
                s1[i].age = s0[i].age + sDot[i].age;
            }

            if (backwindSolve) {

                findDot(s1,sDot);

                for (i = 0; i < particleCount; i++) {
                    sM[i].x = s1[i].x - sDot[i].x;
                    sM[i].y = s1[i].y - sDot[i].y;
                    sM[i].z = s1[i].z - sDot[i].z;

                    sM[i].xVel = s1[i].xVel - sDot[i].xVel;
                    sM[i].yVel = s1[i].yVel - sDot[i].yVel;
                    sM[i].zVel = s1[i].zVel - sDot[i].zVel;

                    sM[i].xForce = s1[i].xForce - sDot[i].xForce;
                    sM[i].yForce = s1[i].yForce - sDot[i].yForce;
                    sM[i].zForce = s1[i].zForce - sDot[i].zForce;

                    sM[i].r = s1[i].r - sDot[i].r;
                    sM[i].g = s1[i].g - sDot[i].g;
                    sM[i].b = s1[i].b - sDot[i].b;
                    sM[i].a = s1[i].a - sDot[i].a;

                    sM[i].mass = s1[i].mass - sDot[i].mass;
                    sM[i].age = s1[i].age - sDot[i].age;
                }

                for (i = 0; i < particleCount; i++) {
                    s1[i].x = s1[i].x + (s0[i].x - sM[i].x) / 2;
                    s1[i].y = s1[i].y + (s0[i].y - sM[i].y) / 2;
                    s1[i].z = s1[i].z + (s0[i].z - sM[i].z) / 2;

                    s1[i].xVel = s1[i].xVel + (s0[i].xVel - sM[i].xVel) / 2;
                    s1[i].yVel = s1[i].yVel + (s0[i].yVel - sM[i].yVel) / 2;
                    s1[i].zVel = s1[i].zVel + (s0[i].zVel - sM[i].zVel) / 2;

                    s1[i].xForce = s1[i].xForce + (s0[i].xForce - sM[i].xForce) / 2;
                    s1[i].yForce = s1[i].yForce + (s0[i].yForce - sM[i].yForce) / 2;
                    s1[i].zForce = s1[i].zForce + (s0[i].zForce - sM[i].zForce) / 2;

                    s1[i].r = s1[i].r + (s0[i].r - sM[i].r) / 2;
                    s1[i].g = s1[i].g + (s0[i].g - sM[i].g) / 2;
                    s1[i].b = s1[i].b + (s0[i].b - sM[i].b) / 2;
                    s1[i].a = s1[i].a + (s0[i].a - sM[i].a) / 2;

                    s1[i].mass = s1[i].mass + (s0[i].mass - sM[i].mass) / 2;
                    s1[i].age = s1[i].age + (s0[i].age - sM[i].age) / 2;
                }
            }
        }

        // checks and constrains s1 if necessary
        void constrain() {
            int i;

            for (i = 0; i < constraintCount; i++) {
                int j;

                switch (c0[i].constraintType) {
                    case C_AXIS:
                    for (j = 0; j < particleCount; j++) {
                        if (s1[j].x > c0[i].xmax) {
                            s1[j].x = c0[i].xmax;
                            s1[j].xVel = -s1[j].xVel * c0[i].bounceLoss;
                        }
                        if (s1[j].x < c0[i].xmin) {
                            s1[j].x = c0[i].xmin;
                            s1[j].xVel = -s1[j].xVel * c0[i].bounceLoss;
                        }
                        if (s1[j].y > c0[i].ymax) {
                            s1[j].y = c0[i].ymax;
                            s1[j].yVel = -s1[j].yVel * c0[i].bounceLoss;
                        }
                        if (s1[j].y < c0[i].ymin) {
                            s1[j].y = c0[i].ymin;
                            s1[j].yVel = -s1[j].yVel * c0[i].bounceLoss;
                        }
                        if (s1[j].z > c0[i].zmax) {
                            s1[j].z = c0[i].zmax;
                            s1[j].zVel = -s1[j].zVel * c0[i].bounceLoss;
                        }
                        if (s1[j].z < c0[i].zmin) {
                            s1[j].z = c0[i].zmin;
                            s1[j].zVel = -s1[j].zVel * c0[i].bounceLoss;
                        }
                    }
                    break;

                    case C_RESET:
                    for (j = 0; j < particleCount; j++) {
                        if (s1[j].age >= c0[i].ageLimit) {
                            s1[j].age = 0;
                            s1[j].x = s1[j].xInit;
                            s1[j].y = s1[j].yInit;
                            s1[j].z = s1[j].zInit;
                            s1[j].xVel = 0;
                            s1[j].yVel = 0;
                            s1[j].zVel = 0;
                            s1[j].r = c0[i].rReset;
                            s1[j].g = c0[i].gReset;
                            s1[j].b = c0[i].bReset;
                            s1[j].a = c0[i].aReset;
                            s1[j].mass = c0[i].massReset;
                        }
                    }
                    break;

                    case C_VELOCITY:
                    for (j = 0; j < particleCount; j++) {
                        if (s1[j].xVel > c0[i].maxVel) {
                            s1[j].xVel = c0[i].maxVel;
                        }
                        if (s1[j].yVel > c0[i].maxVel) {
                            s1[j].yVel = c0[i].maxVel;
                        }
                        if (s1[j].zVel > c0[i].maxVel) {
                            s1[j].zVel = c0[i].maxVel;
                        }
                    }

                    default:
                    break;
                }
            }
        }

        // calls all necessary functions to animate system
        void update() {
            applyAllForces();

            render();
            solve();
            constrain();

            Particle *temp;
            temp = s0;
            s0 = s1;
            s1 = temp;
        }

        // helper functions to create my favorite systems

        void makeRainBox(void) {
            addResetAllConstraint(0,1.0,1.0,1.0,10,500);
            addBoxConstraint(-10,0,-5,5,-10,0,.3);
            addGravityForce(-.005);

            for (int i = 0; i < 1000; i++) {
                addParticle((rand() % 1000) / 100.0 - 10.0,4.95,(rand() % 1000) / 100.0 - 10.0,10,5);
                s0[i].setColor(0,1,1,1);
                s0[i].setColorDeriv(0,-.005,-.003,0);
                s0[i].setAge(rand() % 500);
            }
        }

        void makeJello(void) {
            addGravityForce(-.0001);
            addBoxConstraint(0,10,-5,5,-10,0,.3);

            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    for (int k = 0; k < 5; k++) {
                        addParticle(i+2,j-2,k-4,4,0);
                        addParticleForce(-.0001, i*5+j+k*25,0);
                        if (k != 0) {
                            addSpringForce(.008, 1, i*5+j+(k-1)*25, i*5+j+k*25);
                            addDamperForce(.008, i*5+j+(k-1)*25, i*5+j+k*25);
                        }
                        if (j != 0) {
                            addSpringForce(.008, 1, i*5+j-1+k*25, i*5+j+k*25);
                            addDamperForce(.008, i*5+j-1+k*25, i*5+j+k*25);
                        }
                        if (i != 0) {
                            addSpringForce(.008, 1, (i-1)*5+j+k*25, i*5+j+k*25);
                            addDamperForce(.008, (i-1)*5+j+k*25, i*5+j+k*25);
                        }
                    }
                }
            }
        }

        void makeSpinny(void) {
            addBoxConstraint(-10,0,-5,5,0,10,.9);
            addCylinderForce(.001, -5,0,5, 1,0,1);
            addAxisForce(.3,-5,5,5,1,0,1,0,-.001,0);

            addRotationForce(100,.00005,-5,0,5,0,1,0);

            for (int i = 0; i < 500; i++) {
                addParticle((rand() % 1000) / 100.0 - 10.0,4.9,(rand() % 1000) / 100.0 ,5,10);
                s0[i].setColor(1,(rand() % 10) / 10.0, 0,1);
            }
        }

        void makeAtoms(void) {
            addBoxConstraint(0,10,-5,5,0,10,.4);

            for (int i = 0; i < 50; i++) {
                addParticle((rand() % 400) / 100.0 + 3.0,(rand() % 400) / 100.0 - 2.0,(rand() % 400) / 100.0 + 3.0,1,10);
                addParticleForce(.0001,i,0);
                //p0.addParticleForce(-.007,i,.5);
            }
        }

        void makeTadpoles(void) {
            addBoxConstraint(0,10,-5,5,0,10,.4);

            for (int i = 0; i < 50; i++) {
                addParticle((rand() % 400) / 100.0 +3.0,-1.9,(rand() % 400) / 100.0 +3.0,1,10);
                //p0.addParticleForce(.0001,i,0);
                addParticleForce(-.007,i,.5);
            }

            addGravityForce(-.005);
            addRotationForce(100,.00005,5,0,5,0,1,0);
            addCylinderForce(.00001, 5,0,5, 1,0,1);
        }




};

Particles p0 (0,0,0);
Particles p1 (0,0,0);
Particles p2 (0,0,0);
Particles p3 (0,0,0);
Particles p4 (0,0,0);

bool one = true;
bool two = true;
bool three = true;
bool four = true;



int main( int argc, char *argv[] )
//==============================================================================
{
    //--GLUT/openGL Setup-------------------
	glutInit( &argc, argv );	    // init GLUT user-interface library;
	glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH  );
	glutInitWindowSize(getDisplayWidth(), getDisplayHeight() );
    glutInitWindowPosition(getDisplayXpos(),getDisplayYpos() );

	glutCreateWindow( "Boxed Particle Systems" );

    p0.makeRainBox();
    p1.makeJello();
    p2.makeSpinny();
    p3.makeAtoms();
    p4.makeTadpoles();

    cout << "HELP TEXT *********************************************" << endl;
    cout << "Drag mouse to move camera" << endl;
    cout << "Press A to switch between backwind and forward solvers." << endl;
    cout << "Press Spacebar to poke the Jello." << endl;
    cout << "The number keys 1, 2, 3, and 4 toggle the systems on/off." << endl;
    cout << "*******************************************************" << endl;


	glClearColor( 0, 0, 0, 1 );
	glutDisplayFunc( myDisplay );
	glutReshapeFunc( myReshape);
	glutVisibilityFunc(myHidden);
	glutKeyboardFunc( myKeyboard);
	glutSpecialFunc ( myKeySpecial);
	glutMouseFunc( myMouseClik );
	glutMotionFunc( myMouseMove );
	//================================
    glEnable( GL_DEPTH_TEST );
	glDisable(GL_LIGHTING);
	//================================
    runAnimTimer(1);
	glutMainLoop();
}


void myReshape( int width, int height )
//------------------------------------------------------------------------------
{

    nu_display_width    = width;
    nu_display_height   = height;

    if(width > height)
    {
        glViewport((width-height)/2,0, height, height);
    }
    else
    {
        glViewport(0,(height-width)/2, width, width);

    }


    doCamChoice(2);

	glutPostRedisplay();
}

void myDisplay( void )
//------------------------------------------------------------------------------
{

    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

 	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    glRotated(xcam, 1, 0, 0);
    glRotated(ycam, 0, 1, 0);

    glTranslated(xmov,ymov,zmov);

    glRotated(xtheta, 1.0, 0.0, 0.0);
    glRotated(ytheta, 0.0, 1.0, 0.0);



    if (one) {
        p0.update();
    }
    if (two) {
        p1.update();
    }
    if (three) {
        p2.update();
    }
    if (four) {
        p3.update();
        p4.update();
    }

	glFlush();
	glutSwapBuffers();
}

void myKeyboard(unsigned char key, int xw, int yw)
{
int xpos,ypos;
int camID;

    xpos = xw;
    ypos = getDisplayHeight() - yw;

	switch(key)
	{
        case ' ':
            p1.s0[0].setPosition(p0.s0[0].x+3,p0.s0[0].y+3,p0.s0[0].z+3);
            break;

        case 'r':
        case 'R':       // reset mouse rotations
            xtheta = ytheta = 0;
            xcam = ycam = 0;
            break;

        case 'a':
        case 'A':
            backwindSolve = !backwindSolve;
            break;

		case 27:
		case 'Q':
		case 'q':
			exit(0);    // quit the program.
			break;

        case '1':
        one = !one;
        break;

        case '2':
        two = !two;
        break;

        case '3':
        three = !three;
        break;

        case '4':
        four = !four;
        break;

        default:
            cout << "I don't respond to the %c key.\n" << key << endl;
            break;
	}

    glFlush();
    glutSwapBuffers();
}

void myKeySpecial(int key, int xw, int yw)
{
int xpos,ypos;

    xpos = xw;
    ypos = getDisplayHeight() - yw;
	switch(key)
	{
//	    case GLUT_KEY_F1:
//            showHelp = true;
//            break;
//		case GLUT_KEY_LEFT:		// left arrow key
//            gx -= .1;
//            break;
//		case GLUT_KEY_RIGHT:	// right arrow key
//            gx += .1;
//			break;
//		case GLUT_KEY_DOWN:		// dn arrow key
//            gy -= .1;
//			break;
//		case GLUT_KEY_UP:		// up arrow key
//            gy += .1;
//			break;
//
//		default:
//
//			break;
	}

    glFlush();
    glutSwapBuffers();
}

void myMouseClik(int buttonID, int upDown, int xw, int yw)
{
    int xpos,ypos;  // mouse position in coords with origin at lower left.

    xpos = xw;
    ypos = getDisplayHeight() - yw; //(window system puts origin at UPPER left)

    xclik = xpos;   // save most-recent click in global var
    yclik = ypos;

    if (buttonID == 0) {
        leftDown = true;
        rightDown = false;
    }
    if (buttonID == 2) {
        leftDown = false;
        rightDown = true;
    }
}

void myMouseMove(int xw, int yw)
{
int xpos,ypos;  // mouse position in coords with origin at lower left.

    xpos = xw;
    ypos = getDisplayHeight() - yw; //(window system puts origin at UPPER left)

    if (leftDown) {
        ytheta += 0.3*(xpos-xclik);     // change rot. angle by drag distance
        xtheta -= 0.3*(ypos-yclik);     // (drag in X direction rotates on Y axis)
        xclik = xpos;                   // (drag in Y direction rotates on X axis)
        yclik = ypos;
    }
                      // update current mouse position.
}

void runAnimTimer(int isOn)
//-----------------------------------------------------------------------------
// Call runAnimTimer(0) to STOP animation;
//      runAnimTimer(1) to START or CONTINUE it.
{
    nu_Anim_isOn = isOn;   // Update global var to the most-recent state;
    if(isOn == 1)          // Start or continue animation?
    {   //YES. ANIMATE!   register a GLUT timer callback:
        glutTimerFunc(NU_PAUSE, myTimer, 1);
        // This registers 'myTimer()' as a timer callback function.
        // GLUT will now pause NU_PAUSE milliseconds (longer if busy drawing),
        // call myTimer(1), and then 'un-register' the callback; it won't call
        // myTimer() again unless we register it again.
        // myTimer(1) checks to be SURE no other 'stop animation' requests
        // arrived (e.g. keyboard input, mouse input, visibility change, etc.)
        // while we waited.  If global variable nu_Anim_isOn is STILL 1,
        // it calls runAnimTimer(1) to continue animation.
    }
    // NO.  STOP animation-- don't register a GLUT timer for myTimer().
}

void myTimer (int value)
//------------------------------------------------------------------------------
// Don't call this function yourself; use runAnimTimer() instead!
// runAnimTimer(1) causes GLUT to wait NU_PAUSE milliseconds (longer if busy)
// and then call this function.
// TRICKY: We allow users to choose very long NU_PAUSE times to see what happens
// in animation.  During GLUT's wait time, user events (keyboard, mouse, or
// window cover/uncover) may make runAnimTimer(0) calls intended to STOP
// animation.  GLUT can't cancel a previously-issued GLUT timer callback, so
// in the TimerCallback() function we check global variable nu_Anim_isON.
{
                                // GLUT finished waiting.
    if(value != nu_Anim_isOn)
        cout << "\n(Anim cancelled during GLUT wait)\n";
    if(nu_Anim_isOn==1)         // Go on with animation?
    {                           // YES.
        glutPostRedisplay();    // tell GLUT to re-draw the screen, and
        runAnimTimer(1);        // continue with the next time interval.
    }
                                // NO. Do nothing. No further animation.
}

void myHidden (int isVisible)
//------------------------------------------------------------------------------
// Called by GLUT when our on-screen window gets covered or un-covered. When
// called, it turns off animation and re-display when our display window is
// covered or stowed (not visible). SEE ALSO: runAnimTimer() and myTimer()
{
    if(isVisible == GLUT_VISIBLE)  runAnimTimer(1); // Visible! YES! Animate!
    else runAnimTimer(0);                           // No. Stop animating.
}

// Read the current size and position of the graphics display window
//------------------------------------------------------------------------------
int getDisplayHeight(void) { return nu_display_height; }
int getDisplayWidth(void)  { return nu_display_width; }
int getDisplayXpos(void)   { return nu_display_xpos; }
int getDisplayYpos(void)   { return nu_display_ypos; }


void drawText2D(void * pFont, double x0, double y0, const char* pString)
{
int i, imax;					// character counters

	glRasterPos2d(x0, y0);		// set text's lower-left corner position
	imax = 1023;				// limit the number of chars we print.
	for(i=0; pString[i] != '\0' && i<imax; i++)	// for each char,
	{
		glutBitmapCharacter(pFont, pString[i]);
	}
}

int doCamChoice(int camChoice)
//------------------------------------------------------------------------------
// Switch from current camera to the one specified by 'camChoice'.
// returns ID# for the new current camera choice.
// if camChoice < 0, re-sets current cam choice without changing it.
// Called by myReshape() and myKeyboard() callbacks.
{
static int currentChoice = 0;       // ID# for currently selected camera.

    glMatrixMode( GL_PROJECTION );	// select camera-setting matrix starck
	glLoadIdentity();	           // clear it: identity matrix.
    if(camChoice >= 0) currentChoice = camChoice;   // save new choice,
    // else don't change currentChoice.
    switch(currentChoice)           // apply new choice.
    {
        case 1:         // -----3D Orthographic projection
            glOrtho(-4.0, 4.0,              // left, right
                    0.0, 8.0,              // bottom, top
                    0.0, 100.0);            // zNear, zFar
            cout <<"Cam 1: 3D orthographic"<< endl;
            break;
        case 2:         // -----3D Perspective projection method 1:
            gluPerspective( 70.0, 1.0,      // horiz. FOV(field of view)(degrees), aspect ratio (because CVV is square, Tumblin recommends keeping aspect ratio a square)
                            1.0, 100.0 );    // zNear, zFar clipping planes.
           cout <<"Cam 2: 3D gluPerspective"<< endl;

            break;
        default:
            //cout << "unknown camera. Defaulted to 0: ident (CVV) cam"<< endl;
            doCamChoice(1);
            break;
    }
    glMatrixMode(GL_MODELVIEW);        //return to modelview coords
    return(currentChoice);
}

